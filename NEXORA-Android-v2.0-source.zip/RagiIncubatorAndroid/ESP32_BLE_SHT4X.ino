#include <Arduino.h>
#include <math.h>
#include <Wire.h>
#include <Adafruit_SHT4x.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

#define SDA_PIN 26
#define SCL_PIN 27

static BLEUUID SERVICE_UUID("7b7e0001-7d7a-4f4e-9b8d-2f8c4a6d1000");
static BLEUUID TEMP_UUID("7b7e0002-7d7a-4f4e-9b8d-2f8c4a6d1000");
static BLEUUID HUM_UUID ("7b7e0003-7d7a-4f4e-9b8d-2f8c4a6d1000");
static BLEUUID ENVIRONMENTAL_SERVICE_UUID((uint16_t)0x181A);
static BLEUUID ENVIRONMENTAL_TEMP_UUID((uint16_t)0x2A6E);
static BLEUUID ENVIRONMENTAL_HUM_UUID((uint16_t)0x2A6F);

Adafruit_SHT4x sht4;
BLECharacteristic *tempChar;
BLECharacteristic *humChar;
BLECharacteristic *environmentalTempChar;
BLECharacteristic *environmentalHumChar;
bool connected = false;

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer*) override { connected = true; }
  void onDisconnect(BLEServer*) override {
    connected = false;
    BLEDevice::startAdvertising();
  }
};

void setup() {
  Serial.begin(115200);
  Wire.begin(SDA_PIN, SCL_PIN);
  if (!sht4.begin()) {
    Serial.println("SHT4x not detected. Check SDA=26, SCL=27, 3V3 and GND.");
    while (true) delay(1000);
  }
  sht4.setPrecision(SHT4X_HIGH_PRECISION);
  sht4.setHeater(SHT4X_NO_HEATER);

  BLEDevice::init("Ragi_Incubator");
  BLEServer *server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());
  BLEService *service = server->createService(SERVICE_UUID);

  tempChar = service->createCharacteristic(TEMP_UUID, BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY);
  humChar = service->createCharacteristic(HUM_UUID, BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY);
  tempChar->addDescriptor(new BLE2902());
  humChar->addDescriptor(new BLE2902());
  tempChar->setValue("--");
  humChar->setValue("--");
  service->start();

  BLEService *environmentalService = server->createService(ENVIRONMENTAL_SERVICE_UUID);
  environmentalTempChar = environmentalService->createCharacteristic(
    ENVIRONMENTAL_TEMP_UUID,
    BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY
  );
  environmentalHumChar = environmentalService->createCharacteristic(
    ENVIRONMENTAL_HUM_UUID,
    BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY
  );
  environmentalTempChar->addDescriptor(new BLE2902());
  environmentalHumChar->addDescriptor(new BLE2902());
  uint8_t initialValue[2] = { 0, 0 };
  environmentalTempChar->setValue(initialValue, sizeof(initialValue));
  environmentalHumChar->setValue(initialValue, sizeof(initialValue));
  environmentalService->start();

  BLEAdvertising *advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->setScanResponse(true);
  BLEDevice::startAdvertising();
  Serial.println("BLE ready: Ragi_Incubator");
}

void loop() {
  sensors_event_t humidityEvent, tempEvent;
  if (sht4.getEvent(&humidityEvent, &tempEvent) &&
      isfinite(tempEvent.temperature) && isfinite(humidityEvent.relative_humidity)) {
    char t[16], h[16];
    snprintf(t, sizeof(t), "%.2f", tempEvent.temperature);
    snprintf(h, sizeof(h), "%.2f", humidityEvent.relative_humidity);
    tempChar->setValue(t);
    humChar->setValue(h);

    int32_t temperatureCenti = lroundf(tempEvent.temperature * 100.0f);
    int32_t humidityCenti = lroundf(humidityEvent.relative_humidity * 100.0f);
    temperatureCenti = constrain(temperatureCenti, -32768, 32767);
    humidityCenti = constrain(humidityCenti, 0, 65535);
    const uint16_t temperatureBits = static_cast<uint16_t>(static_cast<int16_t>(temperatureCenti));
    const uint16_t humidityBits = static_cast<uint16_t>(humidityCenti);
    uint8_t temperatureBytes[2] = {
      static_cast<uint8_t>(temperatureBits & 0xFF),
      static_cast<uint8_t>((temperatureBits >> 8) & 0xFF)
    };
    uint8_t humidityBytes[2] = {
      static_cast<uint8_t>(humidityBits & 0xFF),
      static_cast<uint8_t>((humidityBits >> 8) & 0xFF)
    };
    environmentalTempChar->setValue(temperatureBytes, sizeof(temperatureBytes));
    environmentalHumChar->setValue(humidityBytes, sizeof(humidityBytes));
    if (connected) {
      tempChar->notify();
      humChar->notify();
      environmentalTempChar->notify();
      environmentalHumChar->notify();
    }
    Serial.printf("T=%s C, RH=%s %%\n", t, h);
  }
  delay(2000);
}
