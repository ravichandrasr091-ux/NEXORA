package com.muted.ragiincubator

import android.content.Context
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject

enum class SensorKind(val label: String, val unit: String) {
    TEMPERATURE("Temperature", "°C"),
    HUMIDITY("Relative humidity", "% RH"),
    VOC_RAW("VOC raw signal", "ticks")
}

enum class ConnectionMode(val label: String) {
    AUTOMATIC("Automatic"),
    CLASSIC("Bluetooth Classic"),
    BLE("BLE");

    companion object {
        fun fromStored(value: String?): ConnectionMode =
            entries.firstOrNull { it.name == value } ?: AUTOMATIC
    }
}

data class SensorReading(
    val kind: SensorKind,
    val value: Double,
    val timestamp: Long
)

data class ConnectionEvent(
    val state: String,
    val detail: String,
    val timestamp: Long
)

data class BleProfile(
    val serviceUuid: String,
    val temperatureUuid: String,
    val humidityUuid: String,
    val vocUuid: String = ""
) {
    companion object {
        val DEFAULT = BleProfile(
            "7b7e0001-7d7a-4f4e-9b8d-2f8c4a6d1000",
            "7b7e0002-7d7a-4f4e-9b8d-2f8c4a6d1000",
            "7b7e0003-7d7a-4f4e-9b8d-2f8c4a6d1000"
        )
    }
}

class NexoraDataStore(context: Context) {
    private val preferences = context.getSharedPreferences("nexora.device.data", Context.MODE_PRIVATE)

    var deviceAddress: String?
        get() = preferences.getString("device.address", null)
        set(value) { preferences.edit().putString("device.address", value).apply() }

    var deviceName: String?
        get() = preferences.getString("device.name", null)
        set(value) { preferences.edit().putString("device.name", value).apply() }

    var connectionMode: ConnectionMode
        get() = ConnectionMode.fromStored(preferences.getString("connection.mode", null))
        set(value) { preferences.edit().putString("connection.mode", value.name).apply() }

    var lastTransport: ConnectionMode
        get() = ConnectionMode.fromStored(preferences.getString("connection.last_transport", null))
        set(value) { preferences.edit().putString("connection.last_transport", value.name).apply() }

    var autoReconnect: Boolean
        get() = preferences.getBoolean("connection.auto_reconnect", true)
        set(value) { preferences.edit().putBoolean("connection.auto_reconnect", value).apply() }

    var temperatureUnit: String
        get() = preferences.getString("sensor.temperature_unit", "°C") ?: "°C"
        set(value) { preferences.edit().putString("sensor.temperature_unit", value).apply() }

    var samplingIntervalMs: Int
        get() = preferences.getInt("sensor.sampling_interval_ms", 2_000).coerceIn(1_000, 10_000)
        set(value) { preferences.edit().putInt("sensor.sampling_interval_ms", value.coerceIn(1_000, 10_000)).apply() }

    var bleProfile: BleProfile
        get() = BleProfile(
            preferences.getString("ble.service", BleProfile.DEFAULT.serviceUuid) ?: BleProfile.DEFAULT.serviceUuid,
            preferences.getString("ble.temperature", BleProfile.DEFAULT.temperatureUuid) ?: BleProfile.DEFAULT.temperatureUuid,
            preferences.getString("ble.humidity", BleProfile.DEFAULT.humidityUuid) ?: BleProfile.DEFAULT.humidityUuid,
            preferences.getString("ble.voc", BleProfile.DEFAULT.vocUuid) ?: BleProfile.DEFAULT.vocUuid
        )
        set(value) {
            preferences.edit()
                .putString("ble.service", value.serviceUuid)
                .putString("ble.temperature", value.temperatureUuid)
                .putString("ble.humidity", value.humidityUuid)
                .putString("ble.voc", value.vocUuid)
                .apply()
        }

    fun loadReadings(): MutableList<SensorReading> {
        val encoded = preferences.getString("sensor.history", null) ?: return mutableListOf()
        return try {
            val array = JSONArray(encoded)
            MutableList(array.length()) { index ->
                val item = array.getJSONObject(index)
                SensorReading(
                    SensorKind.valueOf(item.getString("kind")),
                    item.getDouble("value"),
                    item.getLong("timestamp")
                )
            }.filterTo(mutableListOf()) { it.value.isFinite() }
        } catch (exception: Exception) {
            Log.w("NEXORA", "Could not read local sensor history.", exception)
            mutableListOf()
        }
    }

    fun saveReadings(readings: List<SensorReading>) {
        val array = JSONArray()
        readings.takeLast(MAX_HISTORY).forEach { reading ->
            array.put(JSONObject()
                .put("kind", reading.kind.name)
                .put("value", reading.value)
                .put("timestamp", reading.timestamp))
        }
        preferences.edit().putString("sensor.history", array.toString()).apply()
    }

    fun clearReadings() {
        preferences.edit().remove("sensor.history").apply()
    }

    fun loadConnectionEvents(): List<ConnectionEvent> {
        val encoded = preferences.getString("connection.history", null) ?: return emptyList()
        return try {
            val array = JSONArray(encoded)
            List(array.length()) { index ->
                val item = array.getJSONObject(index)
                ConnectionEvent(item.getString("state"), item.getString("detail"), item.getLong("timestamp"))
            }
        } catch (exception: Exception) {
            Log.w("NEXORA", "Could not read local connection history.", exception)
            emptyList()
        }
    }

    fun recordConnectionEvent(event: ConnectionEvent) {
        val events = loadConnectionEvents().takeLast(MAX_CONNECTION_EVENTS - 1) + event
        val array = JSONArray()
        events.forEach { entry ->
            array.put(JSONObject()
                .put("state", entry.state)
                .put("detail", entry.detail)
                .put("timestamp", entry.timestamp))
        }
        preferences.edit().putString("connection.history", array.toString()).apply()
    }

    companion object {
        const val MAX_HISTORY = 5000
        private const val MAX_CONNECTION_EVENTS = 100
    }
}
