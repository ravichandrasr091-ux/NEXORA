package com.muted.ragiincubator

import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private enum class Destination(val label: String, val icon: String) {
        HOME("HOME", "⌂"),
        DEVICES("DEVICES", "◈"),
        ANALYTICS("ANALYTICS", "⌁"),
        SETTINGS("SETTINGS", "⚙")
    }
    private val appBackground = 0xFF090D0C.toInt()
    private val surface = 0xFF111916.toInt()
    private val elevated = 0xFF17221D.toInt()
    private val border = 0xFF26372F.toInt()
    private val primary = 0xFFF2F7F4.toInt()
    private val secondary = 0xFF9AA9A3.toInt()
    private val accent = 0xFF35E0A5.toInt()
    private val amber = 0xFFD8B86A.toInt()
    private val danger = 0xFFE07878.toInt()
    private val handler = Handler(Looper.getMainLooper())
    private val storageExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val store by lazy { NexoraDataStore(this) }
    private val history = mutableListOf<SensorReading>()
    private val latestReadings = mutableMapOf<SensorKind, SensorReading>()
    private val discovered = linkedMapOf<String, Pair<BluetoothDevice, Int>>()
    private lateinit var bluetooth: AndroidBluetoothManager
    private lateinit var content: LinearLayout
    private lateinit var bottomNavigation: LinearLayout
    private lateinit var statusLabel: TextView
    private lateinit var statusDetail: TextView
    private lateinit var selectedDeviceLabel: TextView
    private lateinit var homeDeviceStatus: TextView
    private lateinit var homeTemperature: TextView
    private lateinit var homeHumidity: TextView
    private lateinit var homeTemperatureHealth: TextView
    private lateinit var homeHumidityHealth: TextView
    private lateinit var homeLastUpdate: TextView
    private lateinit var homeGraph: HistoryGraph
    private lateinit var homeExtras: LinearLayout
    private var homeVocValue: TextView? = null
    private var homeVocHealth: TextView? = null
    private lateinit var analyticsTemperatureGraph: HistoryGraph
    private lateinit var analyticsHumidityGraph: HistoryGraph
    private lateinit var analyticsExtras: LinearLayout
    private var analyticsVocGraph: HistoryGraph? = null
    private lateinit var analyticsSummary: TextView
    private var destination = Destination.HOME
    private var connectionState = AndroidBluetoothManager.State.DISCONNECTED
    private var connectionDetail = "Not connected"
    private var activeTransport = ConnectionMode.AUTOMATIC
    private var analyticsRangeMs = 60_000L
    private var analyticsPaused = false
    private var lastRetryAt = 0L
    private var retryCount = 0
    private var autoConnectAttempted = false
    private var manuallyDisconnected = false
    private var pendingScanPermission = false
    private var pendingClassicDevice: BluetoothDevice? = null
    private var pendingSavedReconnect = false
    private var requestedExport: String? = null
    private var receiverRegistered = false
    private var screenRefresh: Runnable? = null
    private var historySave: Runnable? = null

    private val adapterReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != android.bluetooth.BluetoothAdapter.ACTION_STATE_CHANGED) return
            when (intent.getIntExtra(android.bluetooth.BluetoothAdapter.EXTRA_STATE, -1)) {
                android.bluetooth.BluetoothAdapter.STATE_OFF,
                android.bluetooth.BluetoothAdapter.STATE_TURNING_OFF -> {
                    bluetooth.disconnect()
                    updateConnectionState(AndroidBluetoothManager.State.DISCONNECTED, "Bluetooth is disabled")
                }
                android.bluetooth.BluetoothAdapter.STATE_ON -> {
                    updateConnectionState(AndroidBluetoothManager.State.DISCONNECTED, "Bluetooth is ready")
                    scheduleAutoReconnect(500)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = appBackground
        window.navigationBarColor = appBackground
        window.decorView.systemUiVisibility = 0
        history.addAll(store.loadReadings())
        history.forEach { reading ->
            if ((latestReadings[reading.kind]?.timestamp ?: 0L) < reading.timestamp) {
                latestReadings[reading.kind] = reading
            }
        }
        bluetooth = AndroidBluetoothManager(this, object : AndroidBluetoothManager.Listener {
            override fun onState(state: AndroidBluetoothManager.State, detail: String) {
                runOnUiThread { onBluetoothState(state, detail) }
            }

            override fun onDeviceFound(device: BluetoothDevice, rssi: Int) {
                runOnUiThread {
                    discovered[device.address] = device to rssi
                    if (destination == Destination.DEVICES) renderScreen()
                }
            }

            override fun onReading(reading: SensorReading) {
                runOnUiThread { acceptReading(reading) }
            }

            override fun onError(message: String) {
                runOnUiThread {
                    connectionDetail = message
                    updateHeader()
                    Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
                }
            }
        })
        buildShell()
        renderScreen()
        requestConnectPermissionIfNeeded()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(android.bluetooth.BluetoothAdapter.ACTION_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(adapterReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else {
            @Suppress("DEPRECATION")
            registerReceiver(adapterReceiver, filter)
        }
        receiverRegistered = true
    }

    override fun onResume() {
        super.onResume()
        refreshStatusTicker()
        if (store.autoReconnect) scheduleAutoReconnect(250)
    }

    override fun onPause() {
        screenRefresh?.let(handler::removeCallbacks)
        screenRefresh = null
        super.onPause()
    }

    override fun onStop() {
        if (receiverRegistered) {
            unregisterReceiver(adapterReceiver)
            receiverRegistered = false
        }
        super.onStop()
    }

    override fun onDestroy() {
        screenRefresh?.let(handler::removeCallbacks)
        historySave?.let(handler::removeCallbacks)
        persistHistory()
        storageExecutor.shutdown()
        handler.removeCallbacksAndMessages(null)
        bluetooth.release()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Android 13")
    override fun onBackPressed() {
        if (destination != Destination.HOME) {
            showDestination(Destination.HOME)
        } else {
            super.onBackPressed()
        }
    }

    private fun buildShell() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(appBackground)
            setOnApplyWindowInsetsListener { view, insets ->
                view.setPadding(0, insets.systemWindowInsetTop, 0, insets.systemWindowInsetBottom)
                insets
            }
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(10))
            setBackgroundColor(appBackground)
        }
        val brandRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val brand = label("NEXORA", 18f, primary, true)
        brand.letterSpacing = 0.08f
        brandRow.addView(brand)
        val tagline = label("CONNECT. MONITOR. CONTROL.", 9f, secondary, true)
        tagline.letterSpacing = 0.06f
        tagline.setPadding(0, dp(2), 0, 0)
        brandRow.addView(tagline)
        header.addView(brandRow)
        selectedDeviceLabel = label("No device selected", 12f, secondary)
        selectedDeviceLabel.setPadding(0, dp(7), 0, 0)
        header.addView(selectedDeviceLabel)
        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, 0)
        }
        statusLabel = label("DISCONNECTED", 10f, secondary, true)
        statusRow.addView(statusLabel)
        statusDetail = label("  ·  Pair or add a device", 10f, secondary)
        statusRow.addView(statusDetail)
        header.addView(statusRow)
        root.addView(header)
        val divider = View(this).apply { setBackgroundColor(border) }
        root.addView(divider, LinearLayout.LayoutParams(-1, dp(1)))
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(12))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(content)
        }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        bottomNavigation = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(5), dp(8), dp(5))
            setBackgroundColor(surface)
        }
        root.addView(bottomNavigation, LinearLayout.LayoutParams(-1, dp(60)))
        setContentView(root)
        root.requestApplyInsets()
        rebuildNavigation()
    }

    private fun renderScreen() {
        if (!::content.isInitialized) return
        content.removeAllViews()
        when (destination) {
            Destination.HOME -> renderHome()
            Destination.DEVICES -> renderDevices()
            Destination.ANALYTICS -> renderAnalytics()
            Destination.SETTINGS -> renderSettings()
        }
        rebuildNavigation()
        updateHeader()
    }

    private fun rebuildNavigation() {
        if (!::bottomNavigation.isInitialized) return
        bottomNavigation.removeAllViews()
        Destination.entries.forEach { item ->
            val selected = item == destination
            val button = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                isFocusable = true
                background = rounded(
                    if (selected) elevated else surface,
                    dp(12),
                    if (selected) border else surface
                )
                setPadding(0, dp(3), 0, dp(3))
                val icon = TextView(this@MainActivity).apply {
                    text = item.icon
                    gravity = Gravity.CENTER
                    textSize = 17f
                    setTextColor(if (selected) accent else secondary)
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                }
                addView(icon, LinearLayout.LayoutParams(-1, dp(24)))
                val title = TextView(this@MainActivity).apply {
                    text = item.label.lowercase().replaceFirstChar { it.uppercase() }
                    gravity = Gravity.CENTER
                    textSize = 10f
                    setTextColor(if (selected) primary else secondary)
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                }
                addView(title, LinearLayout.LayoutParams(-1, dp(18)))
                isClickable = true
                isFocusable = true
                setOnClickListener { showDestination(item) }
                contentDescription = item.label.lowercase().replaceFirstChar { it.uppercase() }
            }
            bottomNavigation.addView(button, LinearLayout.LayoutParams(0, -1, 1f).apply {
                marginStart = dp(3)
                marginEnd = dp(3)
            })
        }
    }

    private fun showDestination(value: Destination) {
        destination = value
        renderScreen()
    }

    private fun renderHome() {
        content.addView(sectionHeader("Live overview", "Your ESP32 telemetry at a glance"))
        val deviceCard = panel("SELECTED DEVICE")
        deviceCard.addView(label(store.deviceName ?: "No device selected", 16f, primary, true))
        homeDeviceStatus = label("", 11f, secondary).apply {
            setPadding(0, dp(4), 0, dp(8))
            maxLines = 2
        }
        deviceCard.addView(homeDeviceStatus)
        val deviceAction = if (connectionState in setOf(
                AndroidBluetoothManager.State.CONNECTED,
                AndroidBluetoothManager.State.RECEIVING
            )) {
            actionButton("DISCONNECT", false) {
                bluetooth.disconnect()
                manuallyDisconnected = true
                updateConnectionState(AndroidBluetoothManager.State.DISCONNECTED, "Disconnected by user")
                renderScreen()
            }
        } else if (connectionState == AndroidBluetoothManager.State.CONNECTING) {
            actionButton("CONNECTING…", false) {}.apply { isEnabled = false }
        } else {
            actionButton("CONNECT DEVICE", true) { reconnectSavedDevice() }
        }
        deviceCard.addView(deviceAction, LinearLayout.LayoutParams(-1, dp(40)))
        content.addView(deviceCard, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(10) })
        val sensorsRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val temperatureCard = panel("TEMPERATURE")
        homeTemperature = label("-- °C", 20f, primary, true).apply {
            maxLines = 1
            setTextIsSelectable(false)
        }
        homeTemperatureHealth = label("Waiting for sensor data", 10f, secondary)
        temperatureCard.addView(homeTemperature)
        temperatureCard.addView(homeTemperatureHealth.apply { setPadding(0, dp(5), 0, 0) })
        val humidityCard = panel("RELATIVE HUMIDITY")
        homeHumidity = label("-- % RH", 20f, primary, true).apply { maxLines = 1 }
        homeHumidityHealth = label("Waiting for sensor data", 10f, secondary)
        humidityCard.addView(homeHumidity)
        humidityCard.addView(homeHumidityHealth.apply { setPadding(0, dp(5), 0, 0) })
        sensorsRow.addView(temperatureCard, LinearLayout.LayoutParams(0, -2, 1f).apply { marginEnd = dp(5) })
        sensorsRow.addView(humidityCard, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(5) })
        content.addView(sensorsRow, LinearLayout.LayoutParams(-1, -2))
        homeExtras = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        homeVocValue = null
        homeVocHealth = null
        content.addView(homeExtras)
        content.addView(sectionTitle("TEMPERATURE HISTORY"))
        homeGraph = HistoryGraph(this)
        content.addView(homeGraph, LinearLayout.LayoutParams(-1, dp(130)))
        homeLastUpdate = label("Last update · No valid sensor reading yet", 10f, secondary)
        homeLastUpdate.setPadding(0, dp(5), 0, dp(2))
        content.addView(homeLastUpdate)
        val actionRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        actionRow.addView(actionButton("MANAGE DEVICES", true) { showDestination(Destination.DEVICES) },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(6) })
        actionRow.addView(actionButton("RECONNECT", false) { reconnectSavedDevice() },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(6) })
        content.addView(actionRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        content.addView(label("Read-only monitoring · safety controls remain on your device firmware.", 10f, secondary).apply {
            setPadding(0, dp(12), 0, 0)
        })
        updateSensorViews()
    }

    private fun renderDevices() {
        content.addView(sectionHeader("Devices", "Saved identity and nearby BLE devices"))
        val savedAddress = store.deviceAddress
        if (savedAddress == null) {
            val empty = panel("NO SAVED DEVICE")
            empty.addView(label("Add a paired Bluetooth Classic device or discover a compatible BLE device.", 12f, secondary))
            content.addView(empty)
        } else {
            val saved = panel("SAVED DEVICE")
            saved.addView(label(store.deviceName ?: savedAddress, 17f, primary, true))
            saved.addView(label(savedAddress, 11f, secondary).apply { setPadding(0, dp(4), 0, dp(8)) })
            saved.addView(label("${store.connectionMode.label} preference · ${statusDescription()}", 11f, secondary))
            val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            buttons.addView(actionButton("CONNECT", true) { reconnectSavedDevice() },
                LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginEnd = dp(5) })
            buttons.addView(actionButton("RENAME", false) { showRenameDialog() },
                LinearLayout.LayoutParams(0, dp(40), 1f).apply {
                    marginStart = dp(5)
                    marginEnd = dp(5)
                })
            buttons.addView(actionButton("REMOVE", false) { removeSavedDevice() },
                LinearLayout.LayoutParams(0, dp(40), 1f).apply { marginStart = dp(5) })
            saved.addView(buttons, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
            if (connectionState == AndroidBluetoothManager.State.CONNECTED ||
                connectionState == AndroidBluetoothManager.State.RECEIVING) {
                saved.addView(actionButton("DISCONNECT", false) {
                    bluetooth.disconnect()
                    manuallyDisconnected = true
                    updateConnectionState(AndroidBluetoothManager.State.DISCONNECTED, "Disconnected by user")
                }, LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin = dp(8) })
            }
            content.addView(saved)
        }

        val sessions = store.loadConnectionEvents()
        if (sessions.isNotEmpty()) {
            val recent = panel("RECENT CONNECTION HISTORY")
            sessions.takeLast(4).asReversed().forEach { event ->
                recent.addView(label(
                    "${formatTimestamp(event.timestamp)} · ${event.state} · ${event.detail.take(70)}",
                    10f,
                    secondary
                ).apply { setPadding(0, dp(3), 0, dp(3)) })
            }
            content.addView(recent, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(9) })
        }

        val bluetoothSettings = actionButton("PAIR CLASSIC DEVICE IN ANDROID SETTINGS", false) {
            try {
                startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            } catch (_: Exception) {
                showMessage("Open Android Settings and choose Bluetooth to pair your device.")
            }
        }
        content.addView(bluetoothSettings, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(10) })

        val scanRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        scanRow.addView(sectionTitle("NEARBY BLE DEVICES"), LinearLayout.LayoutParams(0, -2, 1f))
        scanRow.addView(actionButton("SCAN", true) { startBleScan() }, LinearLayout.LayoutParams(dp(96), dp(38)))
        content.addView(scanRow, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(13) })
        if (discovered.isEmpty()) {
            content.addView(label("BLE scan results appear here. Compatible firmware must expose the SIG Environmental Sensing service or your saved custom profile.", 11f, secondary).apply {
                setPadding(0, dp(7), 0, dp(8))
            })
        }
        discovered.values.forEach { (device, rssi) -> renderDiscoveredDevice(device, rssi) }

        content.addView(sectionTitle("PAIRED CLASSIC DEVICES"))
        val paired = try {
            bluetooth.bondedDevices()
        } catch (_: SecurityException) {
            emptyList()
        }
        if (paired.isEmpty()) {
            content.addView(label("No paired devices found. Pair your ESP32 in Android Bluetooth Settings first.", 11f, secondary))
        } else {
            paired.forEach { device -> renderBondedDevice(device) }
        }
    }

    private fun renderDiscoveredDevice(device: BluetoothDevice, rssi: Int) {
        val row = panel(device.name ?: "BLE device")
        row.addView(label("${device.address}  ·  $rssi dBm", 10f, secondary).apply { setPadding(0, dp(4), 0, dp(8)) })
        row.addView(actionButton("CONNECT OVER BLE", true) {
            connectSelectedDevice(device, ConnectionMode.BLE)
        }, LinearLayout.LayoutParams(-1, dp(40)))
        content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(7) })
    }

    private fun renderBondedDevice(device: BluetoothDevice) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(11), dp(9), dp(10), dp(9))
            background = rounded(surface, dp(12), border)
        }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(label(device.name ?: "Bluetooth device", 13f, primary, true))
        info.addView(label(device.address, 10f, secondary).apply { setPadding(0, dp(3), 0, 0) })
        row.addView(info, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(actionButton("SPP", true) {
            connectSelectedDevice(device, ConnectionMode.CLASSIC)
        }, LinearLayout.LayoutParams(dp(74), dp(38)))
        content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
    }

    private fun renderAnalytics() {
        content.addView(sectionHeader("Analytics", "Stored measurements · no generated samples"))
        val ranges = listOf(
            "1m" to 60_000L,
            "5m" to 300_000L,
            "30m" to 1_800_000L,
            "1h" to 3_600_000L,
            "24h" to 86_400_000L
        )
        val rangeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        ranges.forEach { (label, duration) ->
            val button = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 11f
                setTextColor(if (analyticsRangeMs == duration) accent else secondary)
                isClickable = true
                isFocusable = true
                setPadding(dp(5), dp(10), dp(5), dp(10))
                setOnClickListener {
                    analyticsRangeMs = duration
                    analyticsPaused = false
                    renderScreen()
                }
            }
            rangeRow.addView(button, LinearLayout.LayoutParams(0, dp(38), 1f))
        }
        content.addView(rangeRow)
        val tempPanel = panel("TEMPERATURE · ${displayTemperatureUnit()}")
        analyticsTemperatureGraph = HistoryGraph(this)
        tempPanel.addView(analyticsTemperatureGraph, LinearLayout.LayoutParams(-1, dp(150)))
        content.addView(tempPanel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        val humPanel = panel("RELATIVE HUMIDITY · % RH")
        analyticsHumidityGraph = HistoryGraph(this)
        humPanel.addView(analyticsHumidityGraph, LinearLayout.LayoutParams(-1, dp(150)))
        content.addView(humPanel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
        analyticsExtras = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        analyticsVocGraph = null
        content.addView(analyticsExtras)
        analyticsSummary = label("", 11f, secondary)
        content.addView(analyticsSummary, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(9)
            bottomMargin = dp(8)
        })
        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actionRow.addView(actionButton(if (analyticsPaused) "RESUME" else "PAUSE", false) {
            analyticsPaused = !analyticsPaused
            renderScreen()
        }, LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginEnd = dp(5) })
        actionRow.addView(actionButton("EXPORT CSV", true) { exportCsv() },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply {
                marginStart = dp(5)
                marginEnd = dp(5)
            })
        actionRow.addView(actionButton("CLEAR", false) { confirmClearHistory() },
            LinearLayout.LayoutParams(0, dp(42), 1f).apply { marginStart = dp(5) })
        content.addView(actionRow)
        updateAnalyticsViews()
    }

    private fun renderSettings() {
        content.addView(sectionHeader("Settings", "Connection, sensor units, and local data"))
        val connection = panel("CONNECTION")
        connection.addView(label("Preferred transport", 11f, secondary))
        val modeSpinner = spinner(ConnectionMode.entries.map { it.label }, ConnectionMode.entries.indexOf(store.connectionMode))
        connection.addView(modeSpinner, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(3) })
        modeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                store.connectionMode = ConnectionMode.entries[position]
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        val autoReconnect = Switch(this).apply {
            text = "Reconnect automatically"
            textSize = 13f
            setTextColor(primary)
            isChecked = store.autoReconnect
            setOnCheckedChangeListener { _, checked -> store.autoReconnect = checked }
        }
        connection.addView(autoReconnect, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6) })
        connection.addView(label("Saved device: ${store.deviceName ?: "None"}", 11f, secondary))
        content.addView(connection)

        val sensors = panel("SENSORS")
        sensors.addView(label("Temperature display unit", 11f, secondary))
        val unitSpinner = spinner(listOf("Celsius (°C)", "Fahrenheit (°F)"), if (store.temperatureUnit == "°F") 1 else 0)
        sensors.addView(unitSpinner, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(3) })
        unitSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                store.temperatureUnit = if (position == 1) "°F" else "°C"
                updateSensorViews()
                updateAnalyticsViews()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        sensors.addView(label("BLE read sampling interval", 11f, secondary).apply { setPadding(0, dp(9), 0, 0) })
        val intervals = listOf(1_000, 2_000, 5_000, 10_000)
        val intervalSpinner = spinner(
            intervals.map { "${it / 1000} second${if (it == 1_000) "" else "s"}" },
            intervals.indexOf(store.samplingIntervalMs).takeIf { it >= 0 } ?: 1
        )
        sensors.addView(intervalSpinner, LinearLayout.LayoutParams(-1, dp(46)).apply { topMargin = dp(3) })
        intervalSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                store.samplingIntervalMs = intervals[position]
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        content.addView(sensors, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val profile = panel("CUSTOM BLE PROFILE")
        profile.addView(label("Configure the service and characteristic UUIDs used by your firmware. The SIG environmental profile is always checked too.", 11f, secondary))
        val savedProfile = store.bleProfile
        val serviceInput = textInput("Service UUID", savedProfile.serviceUuid)
        val temperatureInput = textInput("Temperature characteristic UUID", savedProfile.temperatureUuid)
        val humidityInput = textInput("Humidity characteristic UUID", savedProfile.humidityUuid)
        val vocInput = textInput("Optional SGP40 raw signal characteristic UUID", savedProfile.vocUuid)
        profile.addView(serviceInput, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(7) })
        profile.addView(temperatureInput, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6) })
        profile.addView(humidityInput, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6) })
        profile.addView(vocInput, LinearLayout.LayoutParams(-1, dp(48)).apply { topMargin = dp(6) })
        profile.addView(actionButton("SAVE BLE PROFILE", false) {
            val candidate = BleProfile(
                serviceInput.text.toString().trim(),
                temperatureInput.text.toString().trim(),
                humidityInput.text.toString().trim(),
                vocInput.text.toString().trim()
            )
            try {
                candidate.let {
                    AndroidBluetoothManager.uuidFrom(it.serviceUuid)
                    AndroidBluetoothManager.uuidFrom(it.temperatureUuid)
                    AndroidBluetoothManager.uuidFrom(it.humidityUuid)
                    if (it.vocUuid.isNotBlank()) AndroidBluetoothManager.uuidFrom(it.vocUuid)
                }
                store.bleProfile = candidate
                showMessage("BLE profile saved on this device.")
            } catch (_: IllegalArgumentException) {
                showMessage("Enter valid 16-bit, 32-bit, or 128-bit Bluetooth UUIDs.")
            }
        }, LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin = dp(8) })
        content.addView(profile, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })

        val data = panel("DATA AND PRIVACY")
        data.addView(label("${history.size} readings stored locally on this phone. No cloud telemetry is used.", 11f, secondary))
        data.addView(actionButton("EXPORT HISTORY AS CSV", true) { exportCsv() },
            LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin = dp(9) })
        data.addView(actionButton("CLEAR LOCAL HISTORY", false) { confirmClearHistory() },
            LinearLayout.LayoutParams(-1, dp(40)).apply { topMargin = dp(7) })
        data.addView(label("NEXORA · Android app · v2.0", 10f, secondary).apply {
            setPadding(0, dp(10), 0, 0)
        })
        content.addView(data, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
    }

    private fun sectionHeader(title: String, subtitle: String): View {
        val block = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        block.addView(label(title, 19f, primary, true))
        block.addView(label(subtitle, 11f, secondary).apply { setPadding(0, dp(3), 0, dp(9)) })
        return block
    }

    private fun sectionTitle(title: String): TextView =
        label(title, 10f, secondary, true).apply { setPadding(0, dp(12), 0, dp(6)) }

    private fun panel(title: String): LinearLayout {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(10), dp(13), dp(11))
            background = rounded(elevated, dp(13), border)
        }
        container.addView(label(title, 9f, secondary, true).apply {
            letterSpacing = 0.06f
            setPadding(0, 0, 0, dp(6))
        })
        return container
    }

    private fun actionButton(title: String, primaryAction: Boolean, action: () -> Unit): Button =
        Button(this).apply {
            text = title
            textSize = 11f
            isAllCaps = false
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(if (primaryAction) appBackground else primary)
            background = rounded(if (primaryAction) accent else surface, dp(11), if (primaryAction) accent else border)
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener { action() }
        }

    private fun label(textValue: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = textValue
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }

    private fun spinner(values: List<String>, selected: Int): Spinner {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, values).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        return Spinner(this).apply {
            this.adapter = adapter
            setSelection(selected.coerceIn(values.indices))
            setBackgroundColor(surface)
        }
    }

    private fun textInput(hintText: String, value: String): EditText =
        EditText(this).apply {
            hint = hintText
            setText(value)
            textSize = 12f
            setTextColor(primary)
            setHintTextColor(secondary)
            setSingleLine(true)
            setPadding(dp(10), 0, dp(10), 0)
            background = rounded(surface, dp(9), border)
        }

    private fun rounded(color: Int, radius: Int, stroke: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            setStroke(dp(1), stroke)
        }

    private fun updateHeader() {
        if (!::statusLabel.isInitialized) return
        selectedDeviceLabel.text = store.deviceName ?: "No device selected"
        val (text, color) = when (connectionState) {
            AndroidBluetoothManager.State.DISCONNECTED -> "DISCONNECTED" to secondary
            AndroidBluetoothManager.State.SCANNING -> "SCANNING" to amber
            AndroidBluetoothManager.State.CONNECTING -> "CONNECTING" to amber
            AndroidBluetoothManager.State.CONNECTED -> "CONNECTED · NO SENSOR DATA" to amber
            AndroidBluetoothManager.State.RECEIVING -> if (latestReadings.values.any { isFresh(it) }) {
                "RECEIVING DATA" to accent
            } else {
                "CONNECTED · STALE DATA" to amber
            }
            AndroidBluetoothManager.State.ERROR -> "ERROR" to danger
        }
        statusLabel.text = text
        statusLabel.setTextColor(color)
        val transport = when (activeTransport) {
            ConnectionMode.CLASSIC -> "SPP"
            ConnectionMode.BLE -> "BLE"
            ConnectionMode.AUTOMATIC -> null
        }
        statusDetail.text = buildString {
            if (transport != null && connectionState in setOf(
                    AndroidBluetoothManager.State.CONNECTING,
                    AndroidBluetoothManager.State.CONNECTED,
                    AndroidBluetoothManager.State.RECEIVING
                )) append("  ·  $transport")
            if (connectionDetail.isNotBlank()) append("  ·  $connectionDetail")
        }
        if (::homeDeviceStatus.isInitialized) {
            homeDeviceStatus.text = "${statusDescription()}  ·  $connectionDetail"
            homeDeviceStatus.setTextColor(
                when (connectionState) {
                    AndroidBluetoothManager.State.RECEIVING ->
                        if (latestReadings.values.any { isFresh(it) }) accent else amber
                    AndroidBluetoothManager.State.CONNECTING,
                    AndroidBluetoothManager.State.SCANNING -> amber
                    AndroidBluetoothManager.State.ERROR -> danger
                    else -> secondary
                }
            )
        }
        if (::homeTemperature.isInitialized) updateSensorViews()
    }

    private fun onBluetoothState(state: AndroidBluetoothManager.State, detail: String) {
        val previous = connectionState
        connectionState = state
        connectionDetail = detail
        if (state != previous && state in setOf(
                AndroidBluetoothManager.State.CONNECTED,
                AndroidBluetoothManager.State.RECEIVING,
                AndroidBluetoothManager.State.DISCONNECTED,
                AndroidBluetoothManager.State.ERROR
            )) {
            store.recordConnectionEvent(ConnectionEvent(state.name, detail, System.currentTimeMillis()))
        }
        if (state == AndroidBluetoothManager.State.DISCONNECTED ||
            state == AndroidBluetoothManager.State.ERROR) {
            if (!manuallyDisconnected && (previous == AndroidBluetoothManager.State.CONNECTED ||
                previous == AndroidBluetoothManager.State.RECEIVING ||
                previous == AndroidBluetoothManager.State.CONNECTING)) {
                scheduleAutoReconnect()
            }
        }
        updateHeader()
        if (state != previous && ::content.isInitialized && destination == Destination.DEVICES) renderScreen()
    }

    private fun updateConnectionState(state: AndroidBluetoothManager.State, detail: String) {
        connectionState = state
        connectionDetail = detail
        updateHeader()
    }

    private fun acceptReading(reading: SensorReading) {
        val previous = latestReadings[reading.kind]
        if (previous != null && previous.value == reading.value && reading.timestamp - previous.timestamp < 150) return
        latestReadings[reading.kind] = reading
        history.add(reading)
        if (history.size > NexoraDataStore.MAX_HISTORY) history.removeAt(0)
        queueHistorySave()
        retryCount = 0
        if (connectionState != AndroidBluetoothManager.State.RECEIVING) {
            connectionState = AndroidBluetoothManager.State.RECEIVING
        }
        updateHeader()
        updateSensorViews()
        if (!analyticsPaused) updateAnalyticsViews()
    }

    private fun updateSensorViews() {
        if (!::homeTemperature.isInitialized) return
        val temperature = latestReadings[SensorKind.TEMPERATURE]
        val humidity = latestReadings[SensorKind.HUMIDITY]
        val voc = latestReadings[SensorKind.VOC_RAW]
        homeTemperature.text = temperature?.let { formatTemperature(it.value) } ?: "-- ${displayTemperatureUnit()}"
        homeHumidity.text = humidity?.let { String.format(Locale.getDefault(), "%.2f %% RH", it.value) } ?: "-- % RH"
        setHealth(homeTemperatureHealth, temperature)
        setHealth(homeHumidityHealth, humidity)
        if (voc == null) {
            homeExtras.removeAllViews()
            homeVocValue = null
            homeVocHealth = null
        } else {
            if (homeVocValue == null || homeVocHealth == null) {
                val vocCard = panel("SGP40 · RAW VOC SIGNAL")
                val valueView = label("-- ticks", 22f, primary, true)
                val healthView = label("", 10f, secondary)
                homeVocValue = valueView
                homeVocHealth = healthView
                vocCard.addView(valueView)
                vocCard.addView(healthView.apply { setPadding(0, dp(4), 0, 0) })
                homeExtras.removeAllViews()
                homeExtras.addView(vocCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            }
            homeVocValue?.text = String.format(Locale.getDefault(), "%.0f ticks", voc.value)
            homeVocHealth?.let { setHealth(it, voc) }
        }
        val latest = listOfNotNull(temperature, humidity).maxByOrNull { it.timestamp }
        homeLastUpdate.text = latest?.let {
            "Last update · ${formatTimestamp(it.timestamp)} · ${formatRelative(it.timestamp)}"
        } ?: "Last update · No valid sensor reading yet"
        val temperatureHistory = history.filter { it.kind == SensorKind.TEMPERATURE }.map {
            if (store.temperatureUnit == "°F") it.copy(value = it.value * 9.0 / 5.0 + 32.0) else it
        }
        homeGraph.render(temperatureHistory, analyticsRangeMs.coerceAtMost(3_600_000), displayTemperatureUnit())
    }

    private fun setHealth(view: TextView, reading: SensorReading?) {
        if (reading == null) {
            view.text = if (connectionState == AndroidBluetoothManager.State.ERROR) "Error · unavailable" else "Waiting for sensor data"
            view.setTextColor(if (connectionState == AndroidBluetoothManager.State.ERROR) danger else secondary)
        } else if (connectionState != AndroidBluetoothManager.State.RECEIVING || !isFresh(reading)) {
            view.text = "Stale · last ${formatRelative(reading.timestamp)}"
            view.setTextColor(amber)
        } else {
            view.text = "Healthy · ${formatRelative(reading.timestamp)}"
            view.setTextColor(accent)
        }
    }

    private fun updateAnalyticsViews() {
        if (!::analyticsTemperatureGraph.isInitialized || destination != Destination.ANALYTICS) return
        val tempReadings = history.filter {
            it.kind == SensorKind.TEMPERATURE && it.timestamp >= System.currentTimeMillis() - analyticsRangeMs
        }.map { if (store.temperatureUnit == "°F") it.copy(value = it.value * 9.0 / 5.0 + 32.0) else it }
        val humidityReadings = history.filter {
            it.kind == SensorKind.HUMIDITY && it.timestamp >= System.currentTimeMillis() - analyticsRangeMs
        }
        val vocReadings = history.filter {
            it.kind == SensorKind.VOC_RAW && it.timestamp >= System.currentTimeMillis() - analyticsRangeMs
        }
        analyticsTemperatureGraph.render(tempReadings, analyticsRangeMs, displayTemperatureUnit())
        analyticsHumidityGraph.render(humidityReadings, analyticsRangeMs, "% RH")
        if (history.any { it.kind == SensorKind.VOC_RAW }) {
            if (analyticsVocGraph == null) {
                val card = panel("VOC RAW SIGNAL · ticks")
                analyticsVocGraph = HistoryGraph(this)
                card.addView(analyticsVocGraph, LinearLayout.LayoutParams(-1, dp(145)))
                analyticsExtras.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
            }
            analyticsVocGraph?.render(vocReadings, analyticsRangeMs, "ticks")
        }
        val vocSummary = if (history.any { it.kind == SensorKind.VOC_RAW }) {
            "    VOC raw: ${summaryFor(vocReadings)}"
        } else ""
        analyticsSummary.text = "Temperature: ${summaryFor(tempReadings)}    Humidity: ${summaryFor(humidityReadings)}$vocSummary"
    }

    private fun summaryFor(readings: List<SensorReading>): String {
        if (readings.isEmpty()) return "no samples"
        val values = readings.map { it.value }
        val avg = values.average()
        return "min ${"%.1f".format(Locale.US, values.minOrNull())} · max ${"%.1f".format(Locale.US, values.maxOrNull())} · avg ${"%.1f".format(Locale.US, avg)}"
    }

    private fun displayTemperatureUnit(): String = if (store.temperatureUnit == "°F") "°F" else "°C"

    private fun formatTemperature(celsius: Double): String {
        val value = if (store.temperatureUnit == "°F") celsius * 9.0 / 5.0 + 32.0 else celsius
        return String.format(Locale.getDefault(), "%.2f %s", value, displayTemperatureUnit())
    }

    private fun isFresh(reading: SensorReading): Boolean =
        System.currentTimeMillis() - reading.timestamp <= STALE_AFTER_MS

    private fun statusDescription(): String = when (connectionState) {
        AndroidBluetoothManager.State.DISCONNECTED -> "Disconnected"
        AndroidBluetoothManager.State.SCANNING -> "Scanning"
        AndroidBluetoothManager.State.CONNECTING -> "Connecting"
        AndroidBluetoothManager.State.CONNECTED -> "Connected, waiting for data"
        AndroidBluetoothManager.State.RECEIVING -> if (latestReadings.values.any { isFresh(it) }) "Receiving data" else "Stale data"
        AndroidBluetoothManager.State.ERROR -> "Error"
    }

    private fun refreshStatusTicker() {
        val refresh = object : Runnable {
            override fun run() {
                if (isFinishing || isDestroyed) return
                updateHeader()
                if (!analyticsPaused) updateAnalyticsViews()
                handler.postDelayed(this, 1000)
            }
        }
        screenRefresh = refresh
        handler.post(refresh)
    }

    private fun startBleScan() {
        if (!ensureBluetoothPermission(forScan = true)) return
        discovered.clear()
        renderScreen()
        bluetooth.startBleScan(store.bleProfile)
    }

    private fun reconnectSavedDevice() {
        val address = store.deviceAddress
        if (address == null) {
            showDestination(Destination.DEVICES)
            showMessage("Add a device first.")
            return
        }
        if (!ensureBluetoothPermission(forScan = false)) {
            pendingSavedReconnect = true
            return
        }
        val preferred = store.connectionMode
        val transport = if (preferred != ConnectionMode.AUTOMATIC) preferred else store.lastTransport
        val selected = if (transport != ConnectionMode.AUTOMATIC) transport else {
            val paired = try {
                bluetooth.bondedDevices().any { it.address == address }
            } catch (_: SecurityException) {
                false
            }
            if (paired) ConnectionMode.CLASSIC else ConnectionMode.BLE
        }
        activeTransport = selected
        manuallyDisconnected = false
        connectionDetail = "Reconnecting to saved device"
        updateConnectionState(AndroidBluetoothManager.State.CONNECTING, connectionDetail)
        bluetooth.connectSaved(address, selected, store.bleProfile, store.samplingIntervalMs)
    }

    private fun saveAndConnect(device: BluetoothDevice, mode: ConnectionMode) {
        val name = try {
            device.name
        } catch (_: SecurityException) {
            null
        }
        store.deviceAddress = device.address
        store.deviceName = name?.takeIf { it.isNotBlank() } ?: "ESP32 device"
        store.lastTransport = mode
        activeTransport = mode
        manuallyDisconnected = false
        retryCount = 0
        autoConnectAttempted = true
        val preferred = store.connectionMode
        if (preferred == ConnectionMode.AUTOMATIC) store.lastTransport = mode
        when (mode) {
            ConnectionMode.CLASSIC -> bluetooth.connectClassic(device)
            ConnectionMode.BLE -> bluetooth.connectBle(device, store.bleProfile, store.samplingIntervalMs)
            ConnectionMode.AUTOMATIC -> Unit
        }
        renderScreen()
    }

    private fun connectSelectedDevice(device: BluetoothDevice, mode: ConnectionMode) {
        if (Build.VERSION.SDK_INT >= 31 && !hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
            pendingClassicDevice = device
            activeTransport = mode
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), REQUEST_CONNECT_PERMISSION)
            return
        }
        saveAndConnect(device, mode)
    }

    private fun scheduleAutoReconnect(delayMs: Long? = null) {
        if (manuallyDisconnected || !store.autoReconnect || store.deviceAddress == null || retryCount >= MAX_RETRIES) return
        val delay = delayMs ?: RETRY_DELAYS[retryCount.coerceIn(RETRY_DELAYS.indices)]
        val now = SystemClock.elapsedRealtime()
        if (now < lastRetryAt) return
        lastRetryAt = now + delay
        handler.postDelayed({
            if (isFinishing || manuallyDisconnected || !store.autoReconnect || store.deviceAddress == null ||
                connectionState in setOf(
                    AndroidBluetoothManager.State.CONNECTING,
                    AndroidBluetoothManager.State.CONNECTED,
                    AndroidBluetoothManager.State.RECEIVING,
                    AndroidBluetoothManager.State.SCANNING
                )) return@postDelayed
            if (!hasPermission(Manifest.permission.BLUETOOTH_CONNECT) && Build.VERSION.SDK_INT >= 31) {
                requestConnectPermissionIfNeeded()
                return@postDelayed
            }
            if (!bluetooth.isBluetoothEnabled()) {
                connectionDetail = "Bluetooth is disabled"
                updateHeader()
                return@postDelayed
            }
            retryCount += 1
            reconnectSavedDevice()
        }, delay)
    }

    private fun requestConnectPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT < 31 || hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
            tryAutoConnect()
            return
        }
        requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), REQUEST_CONNECT_PERMISSION)
    }

    private fun tryAutoConnect() {
        if (autoConnectAttempted || !store.autoReconnect || store.deviceAddress == null) return
        autoConnectAttempted = true
        reconnectSavedDevice()
    }

    private fun ensureBluetoothPermission(forScan: Boolean): Boolean {
        val permissions = if (Build.VERSION.SDK_INT >= 31) {
            if (forScan) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
            else arrayOf(Manifest.permission.BLUETOOTH_CONNECT)
        } else if (forScan) {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        } else {
            emptyArray()
        }
        val missing = permissions.filterNot(::hasPermission)
        if (missing.isEmpty()) return true
        pendingScanPermission = forScan
        requestPermissions(missing.toTypedArray(), if (forScan) REQUEST_SCAN_PERMISSION else REQUEST_CONNECT_PERMISSION)
        return false
    }

    private fun hasPermission(permission: String): Boolean =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    @Deprecated("Deprecated in Android 13")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_CONNECT_PERMISSION && requestCode != REQUEST_SCAN_PERMISSION) return
        val granted = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        if (!granted) {
            connectionDetail = "Bluetooth permission required"
            updateConnectionState(AndroidBluetoothManager.State.ERROR, connectionDetail)
            showMessage("Grant Bluetooth permission in Android app settings to connect.")
            return
        }
        if (requestCode == REQUEST_SCAN_PERMISSION && pendingScanPermission) {
            pendingScanPermission = false
            startBleScan()
        } else {
            val selectedDevice = pendingClassicDevice
            pendingClassicDevice = null
            if (selectedDevice != null) {
                saveAndConnect(selectedDevice, activeTransport)
            } else if (pendingSavedReconnect) {
                pendingSavedReconnect = false
                reconnectSavedDevice()
            } else if (store.deviceAddress != null && store.autoReconnect) {
                reconnectSavedDevice()
            } else {
                tryAutoConnect()
            }
        }
    }

    private fun showRenameDialog() {
        val input = EditText(this).apply {
            setText(store.deviceName.orEmpty())
            setSelection(text.length)
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Rename device")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val value = input.text.toString().trim()
                if (value.isNotEmpty()) {
                    store.deviceName = value.take(50)
                    renderScreen()
                }
            }
            .show()
    }

    private fun removeSavedDevice() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Remove saved device?")
            .setMessage("This removes the device identity and connection preference from this phone. Local history remains.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Remove") { _, _ ->
                bluetooth.disconnect()
                store.deviceAddress = null
                store.deviceName = null
                store.connectionMode = ConnectionMode.AUTOMATIC
                store.lastTransport = ConnectionMode.AUTOMATIC
                activeTransport = ConnectionMode.AUTOMATIC
                updateConnectionState(AndroidBluetoothManager.State.DISCONNECTED, "Saved device removed")
                renderScreen()
            }
            .show()
    }

    private fun confirmClearHistory() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Clear local history?")
            .setMessage("This permanently removes the sensor readings stored on this phone.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear") { _, _ ->
                history.clear()
                latestReadings.clear()
                historySave?.let(handler::removeCallbacks)
                historySave = null
                storageExecutor.execute { store.clearReadings() }
                updateSensorViews()
                updateAnalyticsViews()
                renderScreen()
            }
            .show()
    }

    private fun exportCsv() {
        if (history.isEmpty()) {
            showMessage("No stored readings to export.")
            return
        }
        requestedExport = buildString {
            appendLine("Timestamp,Device,Sensor,Value,Unit")
            history.forEach { reading ->
                val name = (store.deviceName ?: "ESP32 device").replace("\"", "\"\"")
                val value = if (reading.kind == SensorKind.TEMPERATURE && store.temperatureUnit == "°F") {
                    reading.value * 9.0 / 5.0 + 32.0
                } else reading.value
                val unit = if (reading.kind == SensorKind.TEMPERATURE) displayTemperatureUnit() else reading.kind.unit
                appendLine(
                    "${formatIso(reading.timestamp)},\"$name\",${reading.kind.label},${"%.2f".format(Locale.US, value)},$unit"
                )
            }
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "nexora_sensor_history.csv")
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQUEST_EXPORT)
    }

    @Deprecated("Deprecated in Android 11")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_EXPORT || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                it.write(requestedExport.orEmpty())
            } ?: throw IllegalStateException("Could not open the selected export location.")
            showMessage("CSV exported.")
        } catch (exception: Exception) {
            showMessage("CSV export failed: ${exception.message ?: "storage error"}")
        } finally {
            requestedExport = null
        }
    }

    private fun formatTimestamp(timestamp: Long): String =
        SimpleDateFormat("MMM d, HH:mm:ss", Locale.getDefault()).format(Date(timestamp))

    private fun formatIso(timestamp: Long): String =
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX", Locale.US).format(Date(timestamp))

    private fun formatRelative(timestamp: Long): String {
        val seconds = ((System.currentTimeMillis() - timestamp).coerceAtLeast(0)) / 1000
        return when {
            seconds < 2 -> "just now"
            seconds < 60 -> "${seconds}s ago"
            seconds < 3600 -> "${seconds / 60}m ago"
            else -> "${seconds / 3600}h ago"
        }
    }

    private fun showMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun queueHistorySave() {
        historySave?.let(handler::removeCallbacks)
        val save = Runnable {
            historySave = null
            persistHistory()
        }
        historySave = save
        handler.postDelayed(save, HISTORY_SAVE_DELAY_MS)
    }

    private fun persistHistory() {
        val snapshot = history.toList()
        storageExecutor.execute { store.saveReadings(snapshot) }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val STALE_AFTER_MS = 15_000L
        private const val MAX_RETRIES = 3
        private const val REQUEST_CONNECT_PERMISSION = 501
        private const val REQUEST_SCAN_PERMISSION = 502
        private const val REQUEST_EXPORT = 20
        private const val HISTORY_SAVE_DELAY_MS = 1_000L
        private val RETRY_DELAYS = longArrayOf(1_500, 4_000, 10_000)
    }
}
