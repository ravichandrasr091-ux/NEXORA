package com.muted.ragiincubator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryGraph(context: Context) : View(context) {
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF26372F.toInt(); strokeWidth = dp(1f) }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF35E0A5.toInt()
        strokeWidth = dp(2.2f)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF9AA9A3.toInt()
        textSize = dp(10f)
    }
    private var points: List<SensorReading> = emptyList()
    private var rangeMs = 60_000L
    private var unit = "°C"
    private var emptyText = "Waiting for sensor data"

    fun render(readings: List<SensorReading>, selectedRangeMs: Long, measurementUnit: String) {
        points = readings
        rangeMs = selectedRangeMs
        unit = measurementUnit
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = dp(42f)
        val right = width - dp(8f)
        val top = dp(14f)
        val bottom = height - dp(26f)
        if (right <= left || bottom <= top) return
        for (row in 0..3) {
            val y = top + row * (bottom - top) / 3f
            canvas.drawLine(left, y, right, y, gridPaint)
        }
        val now = System.currentTimeMillis()
        val visible = points.filter { it.timestamp >= now - rangeMs && it.timestamp <= now }
        if (visible.isEmpty()) {
            canvas.drawText(emptyText, left, (top + bottom) / 2f, textPaint)
            canvas.drawText(unit, dp(2f), top + dp(4f), textPaint)
            canvas.drawText("now", right - dp(18f), height - dp(6f), textPaint)
            return
        }
        val minValue = visible.minOf { it.value }
        val maxValue = visible.maxOf { it.value }
        val pad = maxOf((maxValue - minValue) * 0.12, if (unit == "% RH") 0.5 else 0.1)
        val low = minValue - pad
        val span = maxOf((maxValue - minValue) + pad * 2, 0.01)
        canvas.drawText(unit, dp(2f), top + dp(4f), textPaint)
        canvas.drawText(String.format(Locale.US, "%.1f", maxValue), dp(2f), top + dp(18f), textPaint)
        canvas.drawText(String.format(Locale.US, "%.1f", minValue), dp(2f), bottom, textPaint)
        canvas.drawText(
            SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(now - rangeMs)),
            left,
            height - dp(6f),
            textPaint
        )
        canvas.drawText("now", right - dp(18f), height - dp(6f), textPaint)
        if (visible.size == 1) {
            val point = visible.single()
            val x = left + ((point.timestamp - (now - rangeMs)).toFloat() / rangeMs).coerceIn(0f, 1f) * (right - left)
            val y = bottom - ((point.value - low) / span).toFloat() * (bottom - top)
            linePaint.style = Paint.Style.FILL
            canvas.drawCircle(x, y, dp(3f), linePaint)
            linePaint.style = Paint.Style.STROKE
            return
        }
        val path = Path()
        visible.forEachIndexed { index, point ->
            val x = left + ((point.timestamp - (now - rangeMs)).toFloat() / rangeMs).coerceIn(0f, 1f) * (right - left)
            val y = bottom - ((point.value - low) / span).toFloat() * (bottom - top)
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, linePaint)
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density
}
