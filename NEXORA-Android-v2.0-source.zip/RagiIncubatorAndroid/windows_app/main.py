import asyncio
import csv
import threading
import tkinter as tk
from datetime import datetime
from tkinter import filedialog, ttk

from bleak import BleakClient, BleakScanner


SERVICE_UUID = "7b7e0001-7d7a-4f4e-9b8d-2f8c4a6d1000"
TEMP_UUID = "7b7e0002-7d7a-4f4e-9b8d-2f8c4a6d1000"
HUMIDITY_UUID = "7b7e0003-7d7a-4f4e-9b8d-2f8c4a6d1000"


class RagiIncubatorApp:
    def __init__(self, root: tk.Tk) -> None:
        self.root = root
        self.root.title("Ragi Incubator · Experiment Monitor")
        self.root.geometry("760x700")
        self.root.minsize(620, 600)
        self.root.configure(bg="#0d1715")

        self.loop = asyncio.new_event_loop()
        self.loop_thread = threading.Thread(
            target=self._run_event_loop, name="ble-event-loop", daemon=True
        )
        self.loop_thread.start()

        self.client: BleakClient | None = None
        self.connecting = False
        self.closing = False
        self.temperature: float | None = None
        self.humidity: float | None = None
        self.updated_characteristics: set[str] = set()
        self.logging = False
        self.rows: list[tuple[str, str, str]] = []
        self.history: list[float] = []

        self._build_ui()
        self.root.protocol("WM_DELETE_WINDOW", self._close)

    def _build_ui(self) -> None:
        style = ttk.Style()
        style.theme_use("clam")
        style.configure(
            "Action.TButton",
            font=("Segoe UI", 10, "bold"),
            padding=(14, 9),
            background="#70e0a7",
            foreground="#0d1715",
        )
        style.map("Action.TButton", background=[("active", "#95edbd")])
        style.configure(
            "Secondary.TButton",
            font=("Segoe UI", 10),
            padding=(14, 9),
            background="#263b33",
            foreground="#f2f7f4",
        )
        style.map("Secondary.TButton", background=[("active", "#354e44")])

        outer = tk.Frame(self.root, bg="#0d1715", padx=34, pady=28)
        outer.pack(fill="both", expand=True)
        tk.Label(
            outer,
            text="MUTED LABS  ·  EXPERIMENT MONITOR",
            bg="#0d1715",
            fg="#70e0a7",
            font=("Segoe UI", 10, "bold"),
        ).pack(anchor="w")
        tk.Label(
            outer,
            text="Ragi Incubator",
            bg="#0d1715",
            fg="#f2f7f4",
            font=("Segoe UI", 27, "bold"),
        ).pack(anchor="w", pady=(5, 2))

        self.status = tk.StringVar(value="Bluetooth not connected")
        tk.Label(
            outer,
            textvariable=self.status,
            bg="#0d1715",
            fg="#9bb0a8",
            font=("Segoe UI", 10),
        ).pack(anchor="w", pady=(0, 14))

        self.connect_button = ttk.Button(
            outer,
            text="Connect ESP32",
            style="Action.TButton",
            command=self._toggle_connection,
        )
        self.connect_button.pack(anchor="w", pady=(0, 20))

        metrics = tk.Frame(outer, bg="#0d1715")
        metrics.pack(fill="x")
        metrics.columnconfigure((0, 1), weight=1, uniform="metric")
        self.temperature_label = self._metric_card(
            metrics, 0, "TEMPERATURE", "-- °C", "#70e0a7"
        )
        self.humidity_label = self._metric_card(
            metrics, 1, "RELATIVE HUMIDITY", "-- % RH", "#f2f7f4"
        )

        tk.Label(
            outer,
            text="Temperature history",
            bg="#0d1715",
            fg="#f2f7f4",
            font=("Segoe UI", 13, "bold"),
        ).pack(anchor="w", pady=(18, 8))
        self.graph = tk.Canvas(
            outer, height=180, bg="#14221e", highlightthickness=0
        )
        self.graph.pack(fill="x")
        self.graph.bind("<Configure>", lambda _event: self._draw_graph())

        actions = tk.Frame(outer, bg="#0d1715")
        actions.pack(fill="x", pady=(20, 10))
        self.log_button = ttk.Button(
            actions,
            text="Start experiment",
            style="Action.TButton",
            command=self._toggle_logging,
        )
        self.log_button.pack(side="left")
        self.export_button = ttk.Button(
            actions,
            text="Export CSV",
            style="Secondary.TButton",
            command=self._export_csv,
        )
        self.export_button.pack(side="left", padx=(10, 0))

        tk.Label(
            outer,
            text=(
                "Keep this app open while logging. Monitoring only: this app does "
                "not control the heater or provide over-temperature protection."
            ),
            bg="#0d1715",
            fg="#9bb0a8",
            font=("Segoe UI", 9),
            wraplength=680,
            justify="left",
        ).pack(anchor="w", pady=(12, 0))

    @staticmethod
    def _metric_card(
        parent: tk.Frame, column: int, title: str, initial_value: str, value_color: str
    ) -> tk.Label:
        card = tk.Frame(parent, bg="#1b2c27", padx=18, pady=14)
        card.grid(row=0, column=column, sticky="nsew", padx=(0, 8) if column == 0 else (8, 0))
        tk.Label(
            card,
            text=title,
            bg="#1b2c27",
            fg="#9bb0a8",
            font=("Segoe UI", 9, "bold"),
        ).pack(anchor="w")
        value = tk.Label(
            card,
            text=initial_value,
            bg="#1b2c27",
            fg=value_color,
            font=("Segoe UI", 25, "bold"),
        )
        value.pack(anchor="w", pady=(7, 0))
        return value

    def _run_event_loop(self) -> None:
        asyncio.set_event_loop(self.loop)
        self.loop.run_forever()

    def _toggle_connection(self) -> None:
        if self.connecting:
            return
        if self.client and self.client.is_connected:
            asyncio.run_coroutine_threadsafe(self._disconnect(), self.loop)
            return
        self.connecting = True
        self.connect_button.configure(state="disabled")
        self.status.set("Scanning for Ragi_Incubator…")
        asyncio.run_coroutine_threadsafe(self._connect(), self.loop)

    async def _connect(self) -> None:
        client: BleakClient | None = None
        try:
            device = await BleakScanner.find_device_by_filter(
                lambda _device, advertisement: SERVICE_UUID.lower()
                in {uuid.lower() for uuid in (advertisement.service_uuids or [])},
                timeout=12.0,
            )
            if device is None:
                self._ui(self._connection_failed, "ESP32 not found. Check its BLE firmware.")
                return

            self._ui(self.status.set, f"Found {device.name or 'ESP32'} · connecting…")
            client = BleakClient(device, disconnected_callback=self._on_disconnected)
            await client.connect()
            await client.start_notify(
                TEMP_UUID,
                lambda _sender, data: self._on_notification(TEMP_UUID, data),
            )
            await client.start_notify(
                HUMIDITY_UUID,
                lambda _sender, data: self._on_notification(HUMIDITY_UUID, data),
            )
            self.client = client
            self._ui(self._connection_succeeded, device.name or "ESP32")
        except Exception as exc:
            if client and client.is_connected:
                try:
                    await client.disconnect()
                except Exception as cleanup_error:
                    exc.add_note(f"Disconnect cleanup failed: {cleanup_error}")
            self.client = None
            self._ui(self._connection_failed, f"Connection failed: {exc}")

    async def _disconnect(self) -> None:
        client = self.client
        self.client = None
        try:
            if client and client.is_connected:
                await client.disconnect()
            self._ui(self._connection_failed, "Disconnected")
        except Exception as exc:
            self._ui(self._connection_failed, f"Disconnect failed: {exc}")

    def _on_disconnected(self, _client: BleakClient) -> None:
        self.client = None
        if not self.closing:
            self._ui(self._connection_failed, "Disconnected")

    def _on_notification(self, characteristic: str, data: bytearray) -> None:
        try:
            value = float(data.decode("utf-8").strip())
        except (UnicodeDecodeError, ValueError):
            self._ui(self.status.set, "Received an invalid sensor reading from the ESP32.")
            return
        if characteristic == TEMP_UUID:
            self.temperature = value
        elif characteristic == HUMIDITY_UUID:
            self.humidity = value
        else:
            return
        self.updated_characteristics.add(characteristic)
        if TEMP_UUID in self.updated_characteristics and HUMIDITY_UUID in self.updated_characteristics:
            self.updated_characteristics.clear()
            self._ui(self._update_readings, self.temperature, self.humidity)

    def _update_readings(self, temperature: float | None, humidity: float | None) -> None:
        if temperature is None or humidity is None:
            return
        self.temperature_label.configure(text=f"{temperature:.2f} °C")
        self.humidity_label.configure(text=f"{humidity:.2f} % RH")
        self.history.append(temperature)
        self.history = self.history[-60:]
        self._draw_graph()
        if self.logging:
            stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.rows.append((stamp, f"{temperature:.2f}", f"{humidity:.2f}"))

    def _draw_graph(self) -> None:
        self.graph.delete("all")
        width = max(self.graph.winfo_width(), 2)
        height = max(self.graph.winfo_height(), 2)
        for index in range(4):
            y = 12 + index * (height - 24) / 3
            self.graph.create_line(28, y, width - 8, y, fill="#31463e")
        if len(self.history) < 2:
            return
        low = min(self.history) - 0.1
        high = max(self.history) + 0.1
        span = max(0.2, high - low)
        points: list[float] = []
        for index, value in enumerate(self.history):
            x = 28 + index * (width - 40) / (len(self.history) - 1)
            y = height - 12 - (value - low) / span * (height - 24)
            points.extend((x, y))
        self.graph.create_line(
            *points, fill="#70e0a7", width=3, smooth=False
        )

    def _toggle_logging(self) -> None:
        self.logging = not self.logging
        if self.logging:
            self.log_button.configure(text="Stop experiment")
            self.status.set("Logging readings on this laptop")
        else:
            self.log_button.configure(text="Start experiment")
            self.status.set("Logging stopped")

    def _export_csv(self) -> None:
        if not self.rows:
            self.status.set("No logged readings yet. Start an experiment first.")
            return
        path = filedialog.asksaveasfilename(
            title="Export incubator readings",
            defaultextension=".csv",
            initialfile="ragi_incubator_log.csv",
            filetypes=[("CSV files", "*.csv"), ("All files", "*.*")],
        )
        if not path:
            return
        try:
            with open(path, "w", newline="", encoding="utf-8") as output:
                writer = csv.writer(output)
                writer.writerow(("Timestamp", "Temperature_C", "Humidity_percent"))
                writer.writerows(self.rows)
        except OSError as exc:
            self.status.set(f"CSV export failed: {exc}")
            return
        self.status.set(f"CSV exported: {path}")

    def _connection_succeeded(self, device_name: str) -> None:
        self.connecting = False
        self.connect_button.configure(text="Disconnect", state="normal")
        self.status.set(f"Connected to {device_name} · live data")

    def _connection_failed(self, message: str) -> None:
        self.connecting = False
        self.connect_button.configure(text="Connect ESP32", state="normal")
        self.status.set(message)

    def _ui(self, callback: object, *args: object) -> None:
        if not self.closing:
            self.root.after(0, callback, *args)

    def _close(self) -> None:
        self.closing = True

        async def shutdown() -> None:
            try:
                if self.client and self.client.is_connected:
                    await self.client.disconnect()
            finally:
                self.loop.call_soon(self.loop.stop)

        asyncio.run_coroutine_threadsafe(shutdown(), self.loop)
        self.root.destroy()


def main() -> None:
    root = tk.Tk()
    RagiIncubatorApp(root)
    root.mainloop()


if __name__ == "__main__":
    main()
