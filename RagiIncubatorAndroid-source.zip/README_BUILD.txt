RAGI INCUBATOR ANDROID APP + ESP32 BLE FIRMWARE

IMPORTANT
- This is an Android Studio source project, not a precompiled APK.
- The project requires Android Studio / Android SDK and Gradle to build.
- BLE app and ESP32 firmware share these UUIDs. Do not change one side without changing the other.
- The current app reads SHT4x temperature and humidity only. It does not read SGP40 VOC.
- Keep the app open while collecting readings. CSV rows are held in app memory until export; do not force-close before exporting.
- The app monitors only. It does not switch the heater, regulate temperature, or provide an independent over-temperature cutoff.

ESP32 SETUP
1. In Arduino IDE Library Manager install "Adafruit SHT4x Library" and its dependencies.
2. Use ESP32 board package with BLE support (ESP32 Arduino core).
3. Connect SHT4x: VIN->3V3, GND->GND, SDA->GPIO26, SCL->GPIO27.
4. Open ESP32_BLE_SHT4X.ino, select your ESP32 board and port, then upload.
5. Open Serial Monitor at 115200. It should say "BLE ready: Ragi_Incubator".

ANDROID BUILD
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. Android Studio -> Open -> select the RagiIncubatorAndroid folder.
4. Let Gradle sync and install Android SDK Platform 35 if prompted.
5. Build -> Build Bundle(s) / APK(s) -> Build APK(s).
6. APK output is app/build/outputs/apk/debug/app-debug.apk.
7. Transfer that APK to Android phone and install. Android may ask permission to install unknown apps for the file manager/browser you used.
8. Open app, allow Nearby devices/Bluetooth permissions, enable Bluetooth, tap Connect ESP32.

WINDOWS LAPTOP BUILD
1. Install Python 3.10 or newer and make sure Bluetooth is enabled on the laptop.
2. Open PowerShell in the RagiIncubatorAndroid folder.
3. Run: `python -m pip install -r windows_app\requirements.txt`
4. Build the Windows app: `python -m PyInstaller --onefile --windowed --name RagiIncubator windows_app\main.py`
5. The standalone app is created at `dist\RagiIncubator.exe`. Copy it to the laptop and run it.
6. Select Connect ESP32, allow Windows Bluetooth access if prompted, then start the experiment and export the CSV.

COMPATIBILITY
- Android app requires BLE-capable Android phone.
- Windows laptop app requires Windows 10/11 with Bluetooth Low Energy support.
- This project uses Android Gradle Plugin 8.7.3, Kotlin 2.0.21, compile SDK 35.
- If Android Studio suggests a Gradle/SDK update, accept compatible recommended updates.

NOTES
- Temperature and humidity notifications are sent every 2 seconds.
- Start experiment before readings are added to the CSV log.
- Android CSV export uses the document picker; the Windows app saves to a selected CSV file.
- Each CSV row represents a pair of temperature and humidity notifications from the ESP32.
- This is a starter project; test Bluetooth reconnect and logging reliability before using it for a long experiment.
