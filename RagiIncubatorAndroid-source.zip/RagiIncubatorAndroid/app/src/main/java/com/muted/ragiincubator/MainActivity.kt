package com.muted.ragiincubator

import android.Manifest
import android.app.Activity
import android.bluetooth.*
import android.bluetooth.le.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.view.Gravity
import android.view.View
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private val serviceId = UUID.fromString("7b7e0001-7d7a-4f4e-9b8d-2f8c4a6d1000")
    private val tempId = UUID.fromString("7b7e0002-7d7a-4f4e-9b8d-2f8c4a6d1000")
    private val humId = UUID.fromString("7b7e0003-7d7a-4f4e-9b8d-2f8c4a6d1000")
    private val cccd = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private var scanner: BluetoothLeScanner? = null
    private var gatt: BluetoothGatt? = null
    private var temp = Double.NaN
    private var humidity = Double.NaN
    private var hasNewTemp = false
    private var hasNewHumidity = false
    private var started = false
    private val rows = mutableListOf<String>()
    private lateinit var status: TextView
    private lateinit var tempText: TextView
    private lateinit var humText: TextView
    private lateinit var graph: MiniGraph
    private lateinit var connect: Button
    private lateinit var logButton: Button
    private lateinit var exportButton: Button
    private var scanCallback: ScanCallback? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(13, 23, 21)
        window.navigationBarColor = android.graphics.Color.rgb(13, 23, 21)
        buildUi()
        requestBlePermissions()
    }

    private fun buildUi() {
        val bg = 0xFF0D1715.toInt()
        val panel = 0xFF1B2C27.toInt()
        val green = 0xFF70E0A7.toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(22, 28, 22, 20)
            setBackgroundColor(bg)
        }
        fun text(s: String, size: Float, color: Int, bold: Boolean = false) =
            TextView(this).apply { text = s; textSize = size; setTextColor(color); if (bold) setTypeface(null, 1) }
        layout.addView(text("MUTED LABS · EXPERIMENT MONITOR", 11f, green, true))
        layout.addView(text("Ragi Incubator", 27f, -1, true))
        status = text("Bluetooth not connected", 14f, 0xFF9BB0A8.toInt())
        layout.addView(status)
        connect = Button(this).apply { text = "Connect ESP32"; setOnClickListener { startScan() } }
        layout.addView(connect)
        tempText = text("-- °C", 38f, green, true)
        humText = text("-- % RH", 38f, -1, true)
        layout.addView(card("TEMPERATURE", tempText, panel))
        layout.addView(card("RELATIVE HUMIDITY", humText, panel))
        layout.addView(text("Temperature history", 17f, -1, true))
        graph = MiniGraph(this)
        layout.addView(graph, LinearLayout.LayoutParams(-1, 170))
        logButton = Button(this).apply {
            text = "Start experiment"
            setOnClickListener {
                started = !started
                text = if (started) "Stop experiment" else "Start experiment"
                status.text = if (started) "Logging readings on this phone" else "Logging stopped"
            }
        }
        layout.addView(logButton)
        exportButton = Button(this).apply { text = "Export CSV"; setOnClickListener { exportCsv() } }
        layout.addView(exportButton)
        layout.addView(text("Keep the app open during logging. This app monitors only; it does not control or protect the heater.", 12f, 0xFF9BB0A8.toInt()))
        val scroll = ScrollView(this).apply { addView(layout) }
        setContentView(scroll)
    }

    private fun card(label: String, value: TextView, color: Int): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(16, 12, 16, 12)
            setBackgroundColor(color)
        }
        box.addView(TextView(this).apply { text = label; textSize = 11f; setTextColor(0xFF9BB0A8.toInt()) })
        box.addView(value)
        val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 12, 0, 8)
        box.layoutParams = lp
        return box
    }

    private fun requestBlePermissions() {
        val needed = if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        val missing = needed.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) requestPermissions(missing.toTypedArray(), 5)
    }

    private fun startScan() {
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null || !adapter.isEnabled) {
            status.text = "Turn on Bluetooth, then tap Connect"; return
        }
        if (Build.VERSION.SDK_INT >= 31 &&
            (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED ||
             checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED)) {
            requestBlePermissions(); status.text = "Allow Bluetooth permissions"; return
        }
        scanner = adapter.bluetoothLeScanner
        status.text = "Scanning for Ragi_Incubator…"
        connect.isEnabled = false
        val filters = listOf(ScanFilter.Builder().setServiceUuid(android.os.ParcelUuid(serviceId)).build())
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                scanner?.stopScan(this)
                runOnUiThread { status.text = "Found ${result.device.name ?: "ESP32"} · connecting…" }
                gatt = result.device.connectGatt(this@MainActivity, false, gattCallback)
            }
            override fun onScanFailed(errorCode: Int) {
                runOnUiThread { status.text = "BLE scan failed: $errorCode"; connect.isEnabled = true }
            }
        }
        scanner?.startScan(filters, settings, scanCallback)
        Handler(Looper.getMainLooper()).postDelayed({
            scanCallback?.let { scanner?.stopScan(it) }
            if (gatt == null) { status.text = "Not found. Check ESP32 BLE firmware."; connect.isEnabled = true }
        }, 12000)
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, statusCode: Int, newState: Int) {
            runOnUiThread {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    status.text = "Connected · discovering services"
                    g.discoverServices()
                } else {
                    status.text = "Disconnected"; connect.isEnabled = true
                }
            }
        }
        override fun onServicesDiscovered(g: BluetoothGatt, statusCode: Int) {
            val service = g.getService(serviceId)
            if (service == null) { runOnUiThread { status.text = "BLE service UUID mismatch" }; return }
            enableNotify(g, service.getCharacteristic(tempId))
            enableNotify(g, service.getCharacteristic(humId))
            runOnUiThread { status.text = "Connected to ESP32 · live data" }
        }
        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            val value = characteristic.value?.toString(Charsets.UTF_8)?.trim()?.toDoubleOrNull() ?: return
            runOnUiThread {
                if (characteristic.uuid == tempId) {
                    temp = value; tempText.text = String.format(Locale.US, "%.2f °C", value)
                    hasNewTemp = true
                } else if (characteristic.uuid == humId) {
                    humidity = value; humText.text = String.format(Locale.US, "%.2f %% RH", value)
                    hasNewHumidity = true
                }
                if (hasNewTemp && hasNewHumidity && temp.isFinite() && humidity.isFinite()) {
                    hasNewTemp = false
                    hasNewHumidity = false
                    graph.add(temp.toFloat())
                    if (started) {
                        val stamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
                        rows.add("$stamp,${"%.2f".format(Locale.US,temp)},${"%.2f".format(Locale.US,humidity)}")
                    }
                }
            }
        }
    }

    private fun enableNotify(g: BluetoothGatt, ch: BluetoothGattCharacteristic?) {
        if (ch == null) return
        g.setCharacteristicNotification(ch, true)
        val descriptor = ch.getDescriptor(cccd) ?: return
        descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
        g.writeDescriptor(descriptor)
    }

    private fun exportCsv() {
        if (rows.isEmpty()) { Toast.makeText(this, "No logged readings yet. Start experiment first.", Toast.LENGTH_LONG).show(); return }
        val text = "Timestamp,Temperature_C,Humidity_percent\n" + rows.joinToString("\n")
        val uri = android.content.ContentValues()
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "ragi_incubator_log.csv")
        }
        pendingCsv = text
        startActivityForResult(intent, 20)
    }
    private var pendingCsv: String? = null
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 20 && resultCode == RESULT_OK) {
            data?.data?.let { uri -> contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(pendingCsv ?: "") } }
            Toast.makeText(this, "CSV exported", Toast.LENGTH_SHORT).show()
        }
    }
    override fun onDestroy() { gatt?.close(); super.onDestroy() }
}

class MiniGraph(context: android.content.Context) : View(context) {
    private val values = mutableListOf<Float>()
    private val paint = android.graphics.Paint(3)
    fun add(v: Float) { values.add(v); if (values.size > 60) values.removeAt(0); invalidate() }
    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat(); val h = height.toFloat()
        paint.color = 0xFF31463E.toInt(); paint.strokeWidth = 1f
        for (i in 0..3) { val y = 12 + i * (h - 24) / 3; canvas.drawLine(28f,y,w-8,y,paint) }
        if (values.size < 2) return
        val lo = (values.minOrNull() ?: 0f) - .1f
        val hi = (values.maxOrNull() ?: 1f) + .1f
        val span = max(.2f, hi-lo)
        paint.color = 0xFF70E0A7.toInt(); paint.strokeWidth = 3f; paint.style = android.graphics.Paint.Style.STROKE
        val path = android.graphics.Path()
        values.forEachIndexed { i,v ->
            val x = 28f + i * (w-40f) / (values.size-1)
            val y = h-12f - (v-lo)/span*(h-24f)
            if (i==0) path.moveTo(x,y) else path.lineTo(x,y)
        }
        canvas.drawPath(path,paint); paint.style = android.graphics.Paint.Style.FILL
    }
}
