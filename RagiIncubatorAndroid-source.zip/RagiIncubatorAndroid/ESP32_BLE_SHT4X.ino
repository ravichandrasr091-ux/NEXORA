#include <Arduino.h>
#include <Wire.h>
#include <Adafruit_SHT4x.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>

#define SDA_PIN 26
#define SCL_PIN 27

static BLEUUID SERVICE_UUID("7b7e0001-7d7a-4f4e-9b8d-2f8c4a6d1000");
static BLEUUID TEMP_UUID("7b7e0002-7d7a-4f4e-9b8d-2f8c4a6d1000");
static BLEUUID HUM_UUID ("7b7e0003-7d7a-4f4e-9b8d-2f8c4a6d1000");

Adafruit_SHT4x sht4;
BLECharacteristic *tempChar;
BLECharacteristic *humChar;
bool connected = false;

class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer*) override { connected = true; }
  void onDisconnect(BLEServer*) override {
    connected = false;
    BLEDevice::startAdvertising();
  }
};

void setup() {
  Serial.begin(115200);
  Wire.begin(SDA_PIN, SCL_PIN);
  if (!sht4.begin()) {
    Serial.println("SHT4x not detected. Check SDA=26, SCL=27, 3V3 and GND.");
    while (true) delay(1000);
  }
  sht4.setPrecision(SHT4X_HIGH_PRECISION);
  sht4.setHeater(SHT4X_NO_HEATER);

  BLEDevice::init("Ragi_Incubator");
  BLEServer *server = BLEDevice::createServer();
  server->setCallbacks(new ServerCallbacks());
  BLEService *service = server->createService(SERVICE_UUID);

  tempChar = service->createCharacteristic(TEMP_UUID, BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY);
  humChar = service->createCharacteristic(HUM_UUID, BLECharacteristic::PROPERTY_READ | BLECharacteristic::PROPERTY_NOTIFY);
  tempChar->addDescriptor(new BLE2902());
  humChar->addDescriptor(new BLE2902());
  tempChar->setValue("--");
  humChar->setValue("--");
  service->start();

  BLEAdvertising *advertising = BLEDevice::getAdvertising();
  advertising->addServiceUUID(SERVICE_UUID);
  advertising->setScanResponse(true);
  BLEDevice::startAdvertising();
  Serial.println("BLE ready: Ragi_Incubator");
}

void loop() {
  sensors_event_t humidityEvent, tempEvent;
  if (sht4.getEvent(&humidityEvent, &tempEvent)) {
    char t[16], h[16];
    snprintf(t, sizeof(t), "%.2f", tempEvent.temperature);
    snprintf(h, sizeof(h), "%.2f", humidityEvent.relative_humidity);
    tempChar->setValue(t);
    humChar->setValue(h);
    if (connected) {
      tempChar->notify();
      humChar->notify();
    }
    Serial.printf("T=%s C, RH=%s %%\n", t, h);
  }
  delay(2000);
}
