# NEXORA V3.3 App Upgrade and Branding Audit

Audit date: 2026-10-31  
Status: branding audit and repository rename completed. Android V3.2 was deployed; V3.3 creates a separate app identity to avoid package install conflicts.

## Android 3.3 package conflict fix

- Version code 7/name 3.3 uses application ID `com.nexora.iotmonitor`; the Kotlin/Gradle namespace remains `com.muted.ragiincubator`.
- V3.3 can be installed alongside the older `com.muted.ragiincubator` app instead of updating it. Its app-local preferences and sensor history start fresh; the previous installation and its data remain unchanged until the user removes it.
- V3.3 retains the V3.2 dashboard, sensor parsing, BLE/SPP communication and local storage behavior.
- The new application ID does not migrate or share data with old installs. It also does not change Play Protect's classification of an APK.

## Android 3.2 dashboard update

- Version code 6/name 3.2 keeps the existing `com.muted.ragiincubator` application ID and uses the same debug signing certificate as versions 3.1 and 3.1.1.
- The default presentation is dark emerald. Home now uses a temperature gauge, humidity/sensor-health readouts, truthful stored-history trends and selectable time ranges. Devices, analytics and settings use grouped dark surfaces; analytics shows min/max/average only for recorded readings.
- Real ESP32 parsing, BLE UUID profiles, Bluetooth Classic SPP, reconnection, preferences and local history remain on the existing implementation. No fake readings or chart samples were added.
- `assembleDebug` and `lintDebug` succeeded. The APK is 1,084,210 bytes with SHA-256 `6d8a69169a309319ffa56afeca0f256e7d48afa3d6dd06a45f15a0468f15c5fa`.
- No Android handset or emulator is connected here, so physical screen layout, install and Bluetooth testing remain unverified.

## Android 3.1.1 startup update

- Version code 5/name 3.1.1 defers Bluetooth permission requests until a user initiates a connection. Startup only schedules saved-device reconnection when `BLUETOOTH_CONNECT` is already granted.
- The application ID remains `com.muted.ragiincubator`. The 3.1.1 APK uses the same debug signing certificate as 3.1, allowing it to update 3.1 installations; it cannot update 2.0/3.0 because those APKs use a different key.
- `assembleDebug` and `lintDebug` succeeded. The 1,075,731-byte APK checksum is `8f4060fe01e5f2e2455e00d12822728aafb72f815c77eb19eb8387e99c279d44`; the deployed APK checksum matches.
- GitHub Actions run `41205730903` succeeded. The site and all four versioned APK downloads returned HTTP 200.
- A physical Android 15 launch was not available for verification. The reported crash cause remains unconfirmed; if 3.1.1 still force-closes, an AndroidRuntime/logcat trace is needed to diagnose it conclusively.

## Repository identity and deployment

- The original public GitHub repository `ravichandrasr091-ux/RagiIncubatorAndroid` was renamed to `ravichandrasr091-ux/NEXORA` after the user's explicit approval. The remote checkout now uses `https://github.com/ravichandrasr091-ux/NEXORA.git`, branch `main`.
- The Android project folder in Downloads is separate from the Git checkout and is not itself a Git repository.
- The renamed Pages URL `https://ravichandrasr091-ux.github.io/NEXORA/` was verified HTTP 200 after the rename; the old Pages path returned 404 and must not be described as redirected.
- GitHub Pages deploys the `website/` directory. Exact duplicate root-level web files were removed from the repository; four separately labeled Android APK downloads are live.
- Website HTTP checks returned 200 for Android 2.0, 3.0, 3.1, and 3.1.1 APK downloads. The deployed Android 3.1.1 APK checksum matches the local build.

## Android identity, branding, and signing

- The Android application label is already `NEXORA`; the manifest points to `nexora_icon` launcher and round-icon resources.
- The Android V3.1 source uses version code `4`. Kotlin source packages and the Gradle namespace remain `com.muted.ragiincubator`.
- The existing `applicationId` is `com.muted.ragiincubator`. **Preserve it** to keep the installed app identity and local app data compatible.
- Gradle has no release signing configuration or managed release keystore. The live 2.0/3.0 APKs are debug-signed with certificate SHA-256 `c25c4d71123b7de2e7de0bb97800bd662800c0c5a570b82efadbe34401b3ee90`; the local V3.1 debug APK uses certificate SHA-256 `133af7ba25daf54321cf90ad94c3b706b2d8e6cf4bc91e3f4f032dcb47ed4296`.
- No custom splash-screen resource or app notification implementation was found.
- No Android automatic update client is part of the manual-download design. Users download an APK from the website and confirm installation in Android.

## Branding findings by project surface

| Surface | Audit finding | Classification |
|---|---|---|
| Android resources | App label and launcher icon resources use NEXORA. | Verified in V3.1 build. |
| Android package and preferences | `com.muted.ragiincubator` remains in the namespace, application ID, source package paths, and persisted app identity. | Preserve application ID and preference/history compatibility; namespace/package migration requires careful component and storage verification. |
| Android V2 source archive | The old archive name has been changed to `NEXORA-Android-v2.0-source.zip`; V3.1 source is retained separately. | Keep versioned source history. |
| Website `website/` | The deployed site uses NEXORA branding, the new repository URL, canonical metadata, and relative assets. | All three versioned APK downloads verified HTTP 200. |
| Website service worker | `website/sw.js` contains `ragi-incubator-shell-v1` only to recognize and remove a legacy cache. | Retain as intentional cache-cleanup compatibility unless migration tests show it is safe to remove. |
| Repository-root web assets | These were byte-identical duplicates of the deployed `website/` files. | Remove duplicates; GitHub Pages workflow only stages `website/`. |
| Windows application | Visible Windows application branding is NEXORA; its PyInstaller spec is `NEXORA.spec`. | Rebuilt `dist/NEXORA.exe` successfully (12.61 MiB); no old Ragi text remains in Windows source. |
| Documentation | Build documentation now uses the NEXORA Pages URL and explains manual APK installation and the signing-key restriction. | Keep current with deployed APKs. |
| GitHub Actions | `.github/workflows/pages.yml` validates the BLE protocol and stages the preserved APK versions from `website/`. | Keep archive builds and debug re-signing out of deployment. |
| Project and folder names | The Android workspace path retains its existing local folder name; source archive, repository, and Windows spec use NEXORA names. `settings.gradle.kts` names the Gradle project `NEXORA`. | Preserve the user's local workspace path; the GitHub repo, V2 archive, and Windows spec are migrated. |

## Old-reference disposition

### Migrated or removed

- Active repository and website links point to `ravichandrasr091-ux/NEXORA` and its Pages URL.
- Exact duplicate root-level web assets were removed; `website/` is the canonical site source.
- Windows UI text, class, output executable, and PyInstaller spec use NEXORA naming.
- The V2 source archive was renamed and the Pages workflow no longer rebuilds historic APKs with ephemeral keys.

### Must remain for compatibility or history

- Android `applicationId` `com.muted.ragiincubator`; changing it would make the NEXORA APK a different app and prevent normal in-place updates.
- Existing persisted preference/history keys and data format; migrate only with an explicit compatibility path.
- The legacy service-worker cache key while it is needed to evict already-installed site caches.
- The historical V2 source and versioned V2 APK, under NEXORA filenames and clearly labeled as the previous release.

### Third-party or generated items

- Do not rewrite third-party libraries or toolchain identifiers.
- Local `build/`, `dist/`, `.gradle/`, `.kotlin/`, APK intermediates, and Python cache outputs are generated artifacts, not the branding source of truth. Rebuild renamed outputs and do not use blind replacement on them.

## Migration blockers and safety conditions

1. The repository rename is complete. GitHub Pages migration is separate; the old Pages URL returned 404.
2. The live V2/V3 APKs use debug certificate SHA-256 `c25c4d71123b7de2e7de0bb97800bd662800c0c5a570b82efadbe34401b3ee90`. The local V3.1 debug key differs, so V3.1 cannot update those installations in place; uninstalling the old app deletes its local data.
3. Keep the existing application ID and do not advertise the local debug APK as an in-place update. A matching original keystore is required for a seamless update. Do not commit the signing key or request it in chat.
4. Startup sensor history parsing has been moved off the UI thread and the APK/lint builds succeed. Physical launch/crash and Bluetooth testing still needs an Android device because no device/emulator was connected in this workspace.

## Historical V3.1 verification

- At the time of the V3.1 audit, Android `applicationId` was `com.muted.ragiincubator`; APK metadata confirmed version code 4/name 3.1.
- The new Pages deployment and all three APK URLs were verified. The old Pages URL is not redirected.
- Manual-download warning explains that the V3.1 debug signer differs from the published V2/V3 signer; do not claim in-place updates without the original keystore.
