package com.muted.ragiincubator

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.min

class TemperatureGauge(context: Context) : View(context) {
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val valuePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
    }
    private val bounds = RectF()
    private var celsius: Double? = null
    private var formattedValue = "--"
    private var unit = "°C"
    private var primaryColor = 0xFFF2F7F4.toInt()
    private var secondaryColor = 0xFF9AA9A3.toInt()
    private var trackColor = 0xFF20352F.toInt()
    private var accentColor = 0xFF10B981.toInt()

    init {
        contentDescription = "Temperature gauge, no reading available"
    }

    fun render(
        celsius: Double?,
        formattedValue: String,
        unit: String,
        primaryColor: Int,
        secondaryColor: Int,
        trackColor: Int,
        accentColor: Int
    ) {
        this.celsius = celsius?.takeIf { it.isFinite() }
        this.formattedValue = formattedValue
        this.unit = unit
        this.primaryColor = primaryColor
        this.secondaryColor = secondaryColor
        this.trackColor = trackColor
        this.accentColor = accentColor
        contentDescription = this.celsius?.let {
            "Temperature ${formattedValue} $unit"
        } ?: "Temperature gauge, no reading available"
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val stroke = dp(8f)
        val radius = min(width * 0.41f, height * 0.40f)
        if (radius <= stroke) return
        val centerX = width / 2f
        val centerY = height * 0.58f
        bounds.set(centerX - radius, centerY - radius, centerX + radius, centerY + radius)
        trackPaint.color = trackColor
        trackPaint.strokeWidth = stroke
        valuePaint.color = accentColor
        valuePaint.strokeWidth = stroke
        canvas.drawArc(bounds, 135f, 270f, false, trackPaint)
        celsius?.let { temperature ->
            val progress = (temperature / MAX_GAUGE_CELSIUS).coerceIn(0.0, 1.0).toFloat()
            if (progress > 0f) canvas.drawArc(bounds, 135f, 270f * progress, false, valuePaint)
        }

        textPaint.color = secondaryColor
        textPaint.typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
        textPaint.textSize = dp(10f)
        canvas.drawText("TEMPERATURE", centerX, centerY - dp(28f), textPaint)

        textPaint.color = primaryColor
        textPaint.typeface = android.graphics.Typeface.create("sans-serif-light", android.graphics.Typeface.NORMAL)
        textPaint.textSize = dp(36f)
        canvas.drawText(formattedValue, centerX, centerY + dp(10f), textPaint)

        textPaint.color = secondaryColor
        textPaint.textSize = dp(13f)
        canvas.drawText(unit, centerX, centerY + dp(34f), textPaint)

        textPaint.textSize = dp(9f)
        val lowerOffset = radius * 0.72f
        val labelY = centerY + radius * 0.55f
        canvas.drawText(if (unit == "°F") "32" else "0", centerX - lowerOffset, labelY, textPaint)
        canvas.drawText(if (unit == "°F") "122" else "50", centerX + lowerOffset, labelY, textPaint)
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density

    companion object {
        private const val MAX_GAUGE_CELSIUS = 50.0
    }
}
