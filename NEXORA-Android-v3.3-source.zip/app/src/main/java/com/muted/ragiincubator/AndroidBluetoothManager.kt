package com.muted.ragiincubator

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.ArrayDeque
import java.util.Locale
import java.util.UUID
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.regex.Pattern

@SuppressLint("MissingPermission")
class AndroidBluetoothManager(
    context: Context,
    private val listener: Listener
) {
    interface Listener {
        fun onState(state: State, detail: String)
        fun onDeviceFound(device: BluetoothDevice, rssi: Int)
        fun onReading(reading: SensorReading)
        fun onError(message: String)
    }

    enum class State { DISCONNECTED, SCANNING, CONNECTING, CONNECTED, RECEIVING, ERROR }

    private data class SensorCharacteristic(
        val characteristic: BluetoothGattCharacteristic,
        val kind: SensorKind,
        val sigBinary: Boolean,
        val rawVoc: Boolean = false
    )

    private sealed interface GattOperation {
        data class Subscribe(val characteristic: BluetoothGattCharacteristic) : GattOperation
        data class Read(val characteristic: BluetoothGattCharacteristic) : GattOperation
    }

    private val appContext = context.applicationContext
    private val adapter: BluetoothAdapter? =
        (appContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    @Volatile private var socket: android.bluetooth.BluetoothSocket? = null
    @Volatile private var gatt: BluetoothGatt? = null
    @Volatile private var connectionGeneration = 0L
    private var scanCallback: ScanCallback? = null
    private var scanTimeout: Runnable? = null
    private var connectTimeout: Runnable? = null
    private val scanResults = mutableSetOf<String>()
    private val operations = ArrayDeque<GattOperation>()
    private val readableCharacteristics = mutableListOf<BluetoothGattCharacteristic>()
    private var operationInFlight = false
    private var inFlightUuid: UUID? = null
    private var samplingIntervalMs = 2_000L
    private val customTemperatureId = UUID.fromString(BleProfile.DEFAULT.temperatureUuid)
    private val customHumidityId = UUID.fromString(BleProfile.DEFAULT.humidityUuid)
    private val environmentalServiceId = uuidFrom("181A")
    private val environmentalTemperatureId = uuidFrom("2A6E")
    private val environmentalHumidityId = uuidFrom("2A6F")
    private val cccdId = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    private val sppId = UUID.fromString("00001101-0000-1000-8000-00805f9b34fb")

    fun isBluetoothEnabled(): Boolean = adapter?.isEnabled == true

    fun bondedDevices(): List<BluetoothDevice> =
        adapter?.bondedDevices?.sortedBy { it.name ?: it.address } ?: emptyList()

    fun startBleScan(profile: BleProfile = BleProfile.DEFAULT) {
        val bluetoothAdapter = adapter ?: return error("This device does not have Bluetooth.")
        if (!bluetoothAdapter.isEnabled) return error("Bluetooth is disabled. Turn it on and try again.")
        stopScan()
        val scanner = bluetoothAdapter.bluetoothLeScanner ?: return error("BLE scanning is unavailable.")
        scanResults.clear()
        listener.onState(State.SCANNING, "Scanning for compatible BLE devices")
        try {
            uuidFrom(profile.serviceUuid)
        } catch (_: IllegalArgumentException) {
            error("Saved BLE profile contains an invalid service UUID.")
            return
        }
        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val address = result.device.address ?: return
                if (scanResults.add(address)) listener.onDeviceFound(result.device, result.rssi)
            }

            override fun onScanFailed(errorCode: Int) {
                stopScan()
                error("BLE scan failed ($errorCode). Check Bluetooth and permission settings.")
            }
        }
        scanCallback = callback
        try {
            scanner.startScan(callback)
        } catch (exception: SecurityException) {
            error("Bluetooth scan permission is required.")
            return
        } catch (exception: IllegalStateException) {
            error("BLE scanning is not currently available.")
            return
        }
        val timeout = Runnable {
            stopScan()
            if (scanResults.isEmpty()) listener.onState(State.DISCONNECTED, "No compatible BLE devices found.")
            else listener.onState(State.DISCONNECTED, "Scan complete · select a device to connect.")
        }
        scanTimeout = timeout
        mainHandler.postDelayed(timeout, SCAN_DURATION_MS)
    }

    fun stopScan() {
        scanTimeout?.let(mainHandler::removeCallbacks)
        scanTimeout = null
        val callback = scanCallback ?: return
        try {
            adapter?.bluetoothLeScanner?.stopScan(callback)
        } catch (_: SecurityException) {
            listener.onError("Bluetooth scan permission was revoked.")
        }
        scanCallback = null
    }

    fun connectClassic(device: BluetoothDevice) {
        disconnect()
        val generation = connectionGeneration
        listener.onState(State.CONNECTING, "Connecting over Bluetooth Classic SPP")
        val timeout = Runnable {
            if (generation == connectionGeneration && socket?.isConnected != true) {
                connectionGeneration += 1
                closeSocket()
                listener.onState(State.ERROR, "Bluetooth Classic connection timed out")
                listener.onError("ESP32 did not accept the Bluetooth Classic connection in time.")
            }
        }
        connectTimeout = timeout
        mainHandler.postDelayed(timeout, CONNECT_TIMEOUT_MS)
        ioExecutor.execute {
            try {
                val bluetoothAdapter = adapter ?: throw IllegalStateException("Bluetooth is unavailable.")
                bluetoothAdapter.cancelDiscovery()
                val candidate = device.createRfcommSocketToServiceRecord(sppId)
                if (generation != connectionGeneration) {
                    candidate.close()
                    return@execute
                }
                socket = candidate
                candidate.connect()
                if (generation != connectionGeneration) {
                    candidate.close()
                    return@execute
                }
                connectTimeout?.let(mainHandler::removeCallbacks)
                connectTimeout = null
                listener.onState(State.CONNECTED, "Bluetooth Classic socket connected")
                readClassicTelemetry(candidate, generation)
            } catch (exception: Exception) {
                Log.w("NEXORA", "Bluetooth Classic connection attempt failed.", exception)
                if (generation == connectionGeneration) {
                    closeSocket()
                    listener.onState(State.ERROR, "Bluetooth Classic connection failed")
                    listener.onError(classicError(exception))
                }
            }
        }
    }

    private fun readClassicTelemetry(
        connectedSocket: android.bluetooth.BluetoothSocket,
        generation: Long
    ) {
        try {
            val reader = BufferedReader(InputStreamReader(connectedSocket.inputStream, Charsets.UTF_8))
            while (!Thread.currentThread().isInterrupted && generation == connectionGeneration &&
                connectedSocket === socket && connectedSocket.isConnected) {
                val line = reader.readLine() ?: break
                val tempMatch = TEMP_PATTERN.matcher(line)
                val humidityMatch = HUMIDITY_PATTERN.matcher(line)
                val vocMatch = VOC_PATTERN.matcher(line)
                var delivered = false
                if (tempMatch.find()) {
                    tempMatch.group(1)?.toDoubleOrNull()?.takeIf { it in -100.0..200.0 }?.let {
                        deliverReading(SensorKind.TEMPERATURE, it)
                        delivered = true
                    }
                }
                if (humidityMatch.find()) {
                    humidityMatch.group(1)?.toDoubleOrNull()?.takeIf { it in 0.0..100.0 }?.let {
                        deliverReading(SensorKind.HUMIDITY, it)
                        delivered = true
                    }
                }
                if (vocMatch.find()) {
                    vocMatch.group(1)?.toDoubleOrNull()?.takeIf { it in 0.0..65535.0 }?.let {
                        deliverReading(SensorKind.VOC_RAW, it)
                        delivered = true
                    }
                }
                if (delivered && generation == connectionGeneration) {
                    listener.onState(State.RECEIVING, "Receiving valid Bluetooth Classic telemetry")
                }
                if (!delivered && (line.contains("unavailable", true) || line.contains("error", true))) {
                    listener.onError("Sensor reported an unavailable or error state.")
                }
            }
        } catch (exception: Exception) {
            if (generation == connectionGeneration && connectedSocket.isConnected) {
                listener.onError(classicError(exception))
            }
        } finally {
            try {
                connectedSocket.close()
            } catch (closeException: Exception) {
                Log.w("NEXORA", "Could not close Bluetooth socket.", closeException)
            }
            if (generation == connectionGeneration) {
                if (socket === connectedSocket) socket = null
                listener.onState(State.DISCONNECTED, "Bluetooth Classic connection closed")
            }
        }
    }

    fun connectBle(
        device: BluetoothDevice,
        profile: BleProfile = BleProfile.DEFAULT,
        readIntervalMs: Int = 2_000
    ) {
        disconnect()
        requestedProfile = profile
        samplingIntervalMs = readIntervalMs.coerceIn(1_000, 10_000).toLong()
        listener.onState(State.CONNECTING, "Connecting to BLE GATT server")
        val timeout = Runnable {
            val current = gatt
            if (current != null) {
                listener.onState(State.ERROR, "BLE connection timed out")
                listener.onError("The BLE device did not connect in time.")
                closeGatt(current)
            }
        }
        connectTimeout = timeout
        mainHandler.postDelayed(timeout, CONNECT_TIMEOUT_MS)
        try {
            gatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                device.connectGatt(appContext, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
            } else {
                device.connectGatt(appContext, false, gattCallback)
            }
            if (gatt == null) {
                connectTimeout?.let(mainHandler::removeCallbacks)
                connectTimeout = null
                listener.onState(State.ERROR, "BLE connection could not be started")
                listener.onError("The BLE GATT connection could not be started.")
            }
        } catch (exception: SecurityException) {
            connectTimeout?.let(mainHandler::removeCallbacks)
            connectTimeout = null
            listener.onState(State.ERROR, "Bluetooth permission required")
            listener.onError("Bluetooth connect permission is required.")
        }
    }

    fun connectSaved(
        address: String,
        mode: ConnectionMode,
        profile: BleProfile = BleProfile.DEFAULT,
        readIntervalMs: Int = 2_000
    ) {
        val bluetoothAdapter = adapter ?: return error("Bluetooth is unavailable.")
        if (!bluetoothAdapter.isEnabled) return error("Bluetooth is disabled.")
        try {
            val device = bluetoothAdapter.getRemoteDevice(address)
            if (mode == ConnectionMode.CLASSIC) connectClassic(device) else connectBle(device, profile, readIntervalMs)
        } catch (exception: IllegalArgumentException) {
            error("The saved device address is invalid.")
        } catch (exception: SecurityException) {
            error("Bluetooth connect permission is required.")
        }
    }

    fun disconnect() {
        connectionGeneration += 1
        stopScan()
        connectTimeout?.let(mainHandler::removeCallbacks)
        connectTimeout = null
        closeSocket()
        val previousGatt = gatt
        gatt = null
        operations.clear()
        readableCharacteristics.clear()
        characteristicKinds.clear()
        operationInFlight = false
        inFlightUuid = null
        readPoll?.let(mainHandler::removeCallbacks)
        readPoll = null
        try {
            previousGatt?.disconnect()
            previousGatt?.close()
        } catch (exception: SecurityException) {
            listener.onError("Bluetooth permission is required to disconnect.")
        }
    }

    fun release() {
        disconnect()
        ioExecutor.shutdownNow()
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(currentGatt: BluetoothGatt, status: Int, newState: Int) {
            if (currentGatt !== gatt) return
            if (status != BluetoothGatt.GATT_SUCCESS) {
                connectTimeout?.let(mainHandler::removeCallbacks)
                connectTimeout = null
                listener.onState(State.ERROR, "BLE GATT error $status")
                listener.onError("BLE connection failed (GATT status $status).")
                closeGatt(currentGatt)
                listener.onState(State.DISCONNECTED, "BLE disconnected")
                return
            }
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    connectTimeout?.let(mainHandler::removeCallbacks)
                    connectTimeout = null
                    listener.onState(State.CONNECTED, "BLE GATT connected · discovering services")
                    if (!currentGatt.discoverServices()) {
                        listener.onState(State.ERROR, "BLE service discovery could not start")
                        listener.onError("Could not start BLE service discovery.")
                    }
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    closeGatt(currentGatt)
                    listener.onState(State.DISCONNECTED, "BLE device disconnected")
                }
            }
        }

        override fun onServicesDiscovered(currentGatt: BluetoothGatt, status: Int) {
            if (currentGatt !== gatt) return
            if (status != BluetoothGatt.GATT_SUCCESS) {
                listener.onError("BLE service discovery failed (status $status).")
                listener.onState(State.ERROR, "BLE service discovery failed")
                return
            }
            val profile = requestedProfile
            val characteristics = mutableListOf<SensorCharacteristic>()
            currentGatt.getService(environmentalServiceId)?.let { service ->
                service.getCharacteristic(environmentalTemperatureId)?.let {
                    characteristics.add(SensorCharacteristic(it, SensorKind.TEMPERATURE, true))
                }
                service.getCharacteristic(environmentalHumidityId)?.let {
                    characteristics.add(SensorCharacteristic(it, SensorKind.HUMIDITY, true))
                }
            }
            try {
                val customServiceId = uuidFrom(profile.serviceUuid)
                val customService = currentGatt.getService(customServiceId)
                val customTemperatureId = uuidFrom(profile.temperatureUuid)
                val customHumidityId = uuidFrom(profile.humidityUuid)
                customService?.getCharacteristic(customTemperatureId)?.let {
                    characteristics.add(SensorCharacteristic(it, SensorKind.TEMPERATURE, false))
                }
                customService?.getCharacteristic(customHumidityId)?.let {
                    characteristics.add(SensorCharacteristic(it, SensorKind.HUMIDITY, false))
                }
                profile.vocUuid.takeIf { it.isNotBlank() }?.let { vocUuid ->
                    customService?.getCharacteristic(uuidFrom(vocUuid))?.let {
                        characteristics.add(SensorCharacteristic(it, SensorKind.VOC_RAW, false, true))
                    }
                }
            } catch (exception: IllegalArgumentException) {
                listener.onError("Saved BLE profile contains an invalid UUID.")
            }
            val distinct = characteristics
                .distinctBy { it.characteristic.uuid }
                .sortedBy { it.sigBinary }
                .distinctBy { it.kind }
            if (distinct.isEmpty()) {
                listener.onState(State.ERROR, "No supported sensor characteristics found")
                listener.onError("No Environmental Sensing or configured NEXORA sensor characteristics were found.")
                return
            }
            operations.clear()
            characteristicKinds.clear()
            distinct.forEach { sensor ->
                val properties = sensor.characteristic.properties
                if (properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0 ||
                    properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0) {
                    operations.add(GattOperation.Subscribe(sensor.characteristic))
                } else if (properties and BluetoothGattCharacteristic.PROPERTY_READ != 0) {
                    operations.add(GattOperation.Read(sensor.characteristic))
                    readableCharacteristics.add(sensor.characteristic)
                } else {
                    listener.onError("${sensor.kind.label} characteristic cannot be read or subscribed to.")
                }
                characteristicKinds[sensor.characteristic.uuid] = Triple(sensor.kind, sensor.sigBinary, sensor.rawVoc)
            }
            listener.onState(State.CONNECTED, "Services discovered · enabling sensor updates")
            kickGattQueue(currentGatt)
            scheduleReadPoll(currentGatt)
        }

        override fun onDescriptorWrite(currentGatt: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            if (currentGatt !== gatt) return
            operationInFlight = false
            inFlightUuid = null
            if (status != BluetoothGatt.GATT_SUCCESS) {
                listener.onError("Could not enable notifications for ${descriptor.characteristic.uuid}.")
            }
            kickGattQueue(currentGatt)
        }

        override fun onCharacteristicRead(
            currentGatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            if (currentGatt !== gatt) return
            operationInFlight = false
            inFlightUuid = null
            if (status == BluetoothGatt.GATT_SUCCESS) handleCharacteristic(characteristic, characteristic.value)
            else listener.onError("Could not read sensor characteristic ${characteristic.uuid}.")
            kickGattQueue(currentGatt)
        }

        @Deprecated("Deprecated in Android 13")
        override fun onCharacteristicChanged(currentGatt: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            if (currentGatt !== gatt) return
            handleCharacteristic(characteristic, characteristic.value)
        }

        override fun onCharacteristicChanged(
            currentGatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            if (currentGatt !== gatt) return
            handleCharacteristic(characteristic, value)
        }
    }

    private var requestedProfile: BleProfile = BleProfile.DEFAULT
    private val characteristicKinds = mutableMapOf<UUID, Triple<SensorKind, Boolean, Boolean>>()
    private var readPoll: Runnable? = null

    private fun scheduleReadPoll(currentGatt: BluetoothGatt) {
        readPoll?.let(mainHandler::removeCallbacks)
        if (readableCharacteristics.isEmpty()) return
        val poll = object : Runnable {
            override fun run() {
                if (currentGatt !== gatt) return
                readableCharacteristics.forEach { characteristic ->
                    if (operations.none { it is GattOperation.Read && it.characteristic.uuid == characteristic.uuid }) {
                        if (inFlightUuid != characteristic.uuid) operations.add(GattOperation.Read(characteristic))
                    }
                }
                kickGattQueue(currentGatt)
                mainHandler.postDelayed(this, samplingIntervalMs)
            }
        }
        readPoll = poll
        mainHandler.postDelayed(poll, samplingIntervalMs)
    }

    private fun kickGattQueue(currentGatt: BluetoothGatt) {
        if (operationInFlight || currentGatt !== gatt || operations.isEmpty()) return
        val operation = operations.removeFirst()
        val started = when (operation) {
            is GattOperation.Subscribe -> {
                val characteristic = operation.characteristic
                inFlightUuid = characteristic.uuid
                val enabled = currentGatt.setCharacteristicNotification(characteristic, true)
                val descriptor = characteristic.getDescriptor(cccdId)
                if (!enabled || descriptor == null) {
                    listener.onError("Could not subscribe to ${characteristic.uuid}.")
                    false
                } else {
                    val indication = characteristic.properties and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0
                    writeDescriptor(currentGatt, descriptor, if (indication) {
                        BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
                    } else {
                        BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    })
                }
            }
            is GattOperation.Read -> {
                operationInFlight = true
                inFlightUuid = operation.characteristic.uuid
                currentGatt.readCharacteristic(operation.characteristic)
            }
        }
        if (!started) {
            operationInFlight = false
            inFlightUuid = null
            kickGattQueue(currentGatt)
        }
    }

    @Suppress("DEPRECATION")
    private fun writeDescriptor(
        currentGatt: BluetoothGatt,
        descriptor: BluetoothGattDescriptor,
        value: ByteArray
    ): Boolean {
        operationInFlight = true
        inFlightUuid = descriptor.characteristic.uuid
        descriptor.value = value
        return currentGatt.writeDescriptor(descriptor)
    }

    private fun handleCharacteristic(characteristic: BluetoothGattCharacteristic, bytes: ByteArray?) {
        val value = bytes ?: return
        val mapping = characteristicKinds[characteristic.uuid] ?: return
        val parsed = if (mapping.second || mapping.third) {
            if (value.size != 2) null else {
                val raw = (value[0].toInt() and 0xFF) or ((value[1].toInt() and 0xFF) shl 8)
                when {
                    mapping.third -> raw.toDouble()
                    mapping.first == SensorKind.TEMPERATURE && raw and 0x8000 != 0 -> (raw - 0x10000) / 100.0
                    mapping.first == SensorKind.TEMPERATURE || mapping.first == SensorKind.HUMIDITY -> raw / 100.0
                    else -> raw.toDouble()
                }
            }
        } else {
            value.toString(Charsets.UTF_8).trim().toDoubleOrNull()
        } ?: run {
            listener.onError("Invalid ${mapping.first.label.lowercase(Locale.US)} measurement received.")
            return
        }
        val valid = when (mapping.first) {
            SensorKind.TEMPERATURE -> parsed.isFinite() && parsed in -100.0..200.0
            SensorKind.HUMIDITY -> parsed.isFinite() && parsed in 0.0..100.0
            SensorKind.VOC_RAW -> parsed.isFinite() && parsed in 0.0..65535.0
        }
        if (!valid) {
            listener.onError("Out-of-range ${mapping.first.label.lowercase(Locale.US)} measurement rejected.")
            return
        }
        listener.onState(State.RECEIVING, "Receiving valid BLE telemetry")
        deliverReading(mapping.first, parsed)
    }

    private fun deliverReading(kind: SensorKind, value: Double) {
        mainHandler.post {
            listener.onReading(SensorReading(kind, value, System.currentTimeMillis()))
        }
    }

    private fun closeSocket() {
        try {
            socket?.close()
        } catch (exception: Exception) {
            Log.w("NEXORA", "Could not close Bluetooth socket.", exception)
        } finally {
            socket = null
        }
    }

    private fun closeGatt(target: BluetoothGatt) {
        if (target === gatt) gatt = null
        try {
            target.close()
        } catch (exception: SecurityException) {
            listener.onError("Bluetooth permission is required to close the GATT connection.")
        }
    }

    private fun error(message: String) {
        listener.onState(State.ERROR, message)
        listener.onError(message)
    }

    private fun classicError(exception: Exception): String = when (exception) {
        is SecurityException -> "Bluetooth permission is required for this device."
        is java.io.IOException -> "ESP32 is not reachable or the SPP connection was interrupted."
        else -> exception.message ?: "Bluetooth Classic connection failed."
    }

    companion object {
        private const val SCAN_DURATION_MS = 12_000L
        private const val CONNECT_TIMEOUT_MS = 15_000L
        private val TEMP_PATTERN = Pattern.compile(
            "(?i)\\b(?:temperature|temp)\\s*[:=]\\s*(-?\\d+(?:\\.\\d+)?)"
        )
        private val HUMIDITY_PATTERN = Pattern.compile(
            "(?i)\\b(?:relative\\s+humidity|humidity|rh)\\s*[:=]\\s*(-?\\d+(?:\\.\\d+)?)"
        )
        private val VOC_PATTERN = Pattern.compile(
            "(?i)\\b(?:voc(?:\\s+raw)?|raw\\s+voc)\\s*[:=]\\s*(\\d+(?:\\.\\d+)?)"
        )

        fun uuidFrom(input: String): UUID {
            val value = input.trim().removePrefix("0x").removePrefix("0X")
            return when {
                value.length == 4 -> UUID.fromString("0000${value.lowercase(Locale.US)}-0000-1000-8000-00805f9b34fb")
                value.length == 8 -> UUID.fromString("${value.lowercase(Locale.US)}-0000-1000-8000-00805f9b34fb")
                else -> UUID.fromString(value)
            }
        }
    }

    init {
        requestedProfile = BleProfile.DEFAULT
    }
}
