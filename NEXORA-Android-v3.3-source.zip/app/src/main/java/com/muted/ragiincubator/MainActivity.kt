package com.muted.ragiincubator

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private data class AnalyticsSummaryBinding(
        val values: List<TextView>,
        val unit: String
    )

    private enum class Destination(val label: String, val icon: String) {
        HOME("Home", "⌂"),
        DEVICES("Devices", "◇"),
        ANALYTICS("Analytics", "▥"),
        SETTINGS("Settings", "⚙")
    }
    private var appBackground = 0xFFF7F6F1.toInt()
    private var surface = 0xFFFBFAF7.toInt()
    private var elevated = 0xFFF1F0EA.toInt()
    private var border = 0xFFE1E0D9.toInt()
    private var primary = 0xFF202720.toInt()
    private var secondary = 0xFF737C74.toInt()
    private var accent = 0xFF315B45.toInt()
    private var amber = 0xFF9A6B25.toInt()
    private var danger = 0xFFAA4845.toInt()
    private var isDarkTheme = false
    private val handler = Handler(Looper.getMainLooper())
    private val storageExecutor: ExecutorService = Executors.newSingleThreadExecutor()
    private val store by lazy { NexoraDataStore(this) }
    private val history = mutableListOf<SensorReading>()
    private val latestReadings = mutableMapOf<SensorKind, SensorReading>()
    private var historyLoaded = false
    private val discovered = linkedMapOf<String, Pair<BluetoothDevice, Int>>()
    private lateinit var bluetooth: AndroidBluetoothManager
    private lateinit var content: LinearLayout
    private lateinit var bottomNavigation: LinearLayout
    private lateinit var shellRoot: LinearLayout
    private lateinit var headerRoot: LinearLayout
    private lateinit var shellDivider: View
    private lateinit var statusLabel: TextView
    private lateinit var statusDetail: TextView
    private lateinit var selectedDeviceLabel: TextView
    private lateinit var homeDeviceStatus: TextView
    private lateinit var homeHumidity: TextView
    private lateinit var homeTemperatureHealth: TextView
    private lateinit var homeHumidityHealth: TextView
    private lateinit var homeLastUpdate: TextView
    private lateinit var homeGauge: TemperatureGauge
    private lateinit var homeGraph: HistoryGraph
    private lateinit var homeAvailability: TextView
    private lateinit var homeExtras: LinearLayout
    private val homeRangeButtons = mutableMapOf<Long, TextView>()
    private var homeVocValue: TextView? = null
    private var homeVocHealth: TextView? = null
    private lateinit var analyticsTemperatureGraph: HistoryGraph
    private lateinit var analyticsHumidityGraph: HistoryGraph
    private lateinit var analyticsExtras: LinearLayout
    private var analyticsVocGraph: HistoryGraph? = null
    private lateinit var analyticsSummary: LinearLayout
    private val analyticsSummaryBindings = mutableMapOf<SensorKind, AnalyticsSummaryBinding>()
    private val analyticsRangeButtons = mutableMapOf<Long, TextView>()
    private lateinit var appearanceSpinner: Spinner
    private var destination = Destination.HOME
    private var connectionState = AndroidBluetoothManager.State.DISCONNECTED
    private var connectionDetail = "Not connected"
    private var activeTransport = ConnectionMode.AUTOMATIC
    private var homeRangeMs = 3_600_000L
    private var analyticsRangeMs = 3_600_000L
    private var lastRetryAt = 0L
    private var retryCount = 0
    private var manuallyDisconnected = false
    private var pendingScanPermission = false
    private var pendingClassicDevice: BluetoothDevice? = null
    private var pendingSavedReconnect = false
    private var requestedExport: String? = null
    private var receiverRegistered = false
    private var screenRefresh: Runnable? = null
    private var historySave: Runnable? = null

    private val adapterReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action != android.bluetooth.BluetoothAdapter.ACTION_STATE_CHANGED) return
            when (intent.getIntExtra(android.bluetooth.BluetoothAdapter.EXTRA_STATE, -1)) {
                android.bluetooth.BluetoothAdapter.STATE_OFF,
                android.bluetooth.BluetoothAdapter.STATE_TURNING_OFF -> {
                    bluetooth.disconnect()
                    updateConnectionState(AndroidBluetoothManager.State.DISCONNECTED, "Bluetooth is disabled")
                }
                android.bluetooth.BluetoothAdapter.STATE_ON -> {
                    updateConnectionState(AndroidBluetoothManager.State.DISCONNECTED, "Bluetooth is ready")
                    scheduleAutoReconnect(500)
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        applyAppearance()
        configureEdgeToEdge()
        bluetooth = AndroidBluetoothManager(this, object : AndroidBluetoothManager.Listener {
            override fun onState(state: AndroidBluetoothManager.State, detail: String) {
                runOnUiThread { onBluetoothState(state, detail) }
            }

            override fun onDeviceFound(device: BluetoothDevice, rssi: Int) {
                runOnUiThread {
                    discovered[device.address] = device to rssi
                    if (destination == Destination.DEVICES) renderScreen()
                }
            }

            override fun onReading(reading: SensorReading) {
                runOnUiThread { acceptReading(reading) }
            }

            override fun onError(message: String) {
                runOnUiThread {
                    connectionDetail = message
                    updateHeader()
                    Toast.makeText(this@MainActivity, message, Toast.LENGTH_LONG).show()
                }
            }
        })
        buildShell()
        renderScreen()
        loadStoredHistory()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(android.bluetooth.BluetoothAdapter.ACTION_STATE_CHANGED)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(adapterReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        else {
            @Suppress("DEPRECATION")
            registerReceiver(adapterReceiver, filter)
        }
        receiverRegistered = true
    }

    override fun onResume() {
        super.onResume()
        refreshStatusTicker()
        if (store.autoReconnect &&
            store.deviceAddress != null &&
            (Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
                hasPermission(Manifest.permission.BLUETOOTH_CONNECT))
        ) {
            scheduleAutoReconnect(250)
        }
    }

    override fun onPause() {
        screenRefresh?.let(handler::removeCallbacks)
        screenRefresh = null
        super.onPause()
    }

    override fun onStop() {
        if (receiverRegistered) {
            unregisterReceiver(adapterReceiver)
            receiverRegistered = false
        }
        super.onStop()
    }

    override fun onDestroy() {
        screenRefresh?.let(handler::removeCallbacks)
        historySave?.let(handler::removeCallbacks)
        persistHistory()
        storageExecutor.shutdown()
        handler.removeCallbacksAndMessages(null)
        bluetooth.release()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Android 13")
    override fun onBackPressed() {
        if (destination != Destination.HOME) {
            showDestination(Destination.HOME)
        } else {
            super.onBackPressed()
        }
    }

    private fun buildShell() {
        shellRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(appBackground)
            setOnApplyWindowInsetsListener { view, insets ->
                val topInset: Int
                val bottomInset: Int
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bars = insets.getInsets(android.view.WindowInsets.Type.systemBars())
                    topInset = bars.top
                    bottomInset = bars.bottom
                } else {
                    @Suppress("DEPRECATION")
                    run {
                        topInset = insets.systemWindowInsetTop
                        bottomInset = insets.systemWindowInsetBottom
                    }
                }
                view.setPadding(0, topInset, 0, bottomInset)
                insets
            }
        }
        headerRoot = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(9), dp(22), dp(9))
            setBackgroundColor(appBackground)
        }
        val brandRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val brand = label("NEXORA", 18f, primary, true)
        brand.letterSpacing = 0.08f
        brandRow.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        val tagline = label("CONNECT. MONITOR. CONTROL.", 9f, secondary, true)
        tagline.letterSpacing = 0.06f
        brandRow.addView(tagline)
        headerRoot.addView(brandRow)
        val statusRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(5), 0, 0)
        }
        selectedDeviceLabel = label("ESP32-SENSOR", 11f, primary, true).apply {
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
        }
        statusRow.addView(selectedDeviceLabel, LinearLayout.LayoutParams(0, -2, 1f))
        statusLabel = label("●", 10f, secondary, true)
        statusRow.addView(statusLabel)
        statusDetail = label("  Disconnected", 10f, secondary)
        statusRow.addView(statusDetail)
        headerRoot.addView(statusRow)
        shellRoot.addView(headerRoot)
        shellDivider = View(this).apply { setBackgroundColor(border) }
        shellRoot.addView(shellDivider, LinearLayout.LayoutParams(-1, dp(1)))
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(16), dp(18), dp(12))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(content)
        }
        shellRoot.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        bottomNavigation = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(5), dp(8), dp(5))
            setBackgroundColor(surface)
        }
        shellRoot.addView(bottomNavigation, LinearLayout.LayoutParams(-1, dp(62)))
        setContentView(shellRoot)
        configureEdgeToEdge()
        shellRoot.requestApplyInsets()
        rebuildNavigation()
    }

    private fun renderScreen() {
        if (!::content.isInitialized) return
        content.setBackgroundColor(appBackground)
        content.setPadding(dp(20), dp(18), dp(20), dp(18))
        shellRoot.setBackgroundColor(appBackground)
        headerRoot.setBackgroundColor(appBackground)
        shellDivider.setBackgroundColor(border)
        bottomNavigation.setBackgroundColor(surface)
        content.removeAllViews()
        when (destination) {
            Destination.HOME -> renderHome()
            Destination.DEVICES -> renderDevices()
            Destination.ANALYTICS -> renderAnalytics()
            Destination.SETTINGS -> renderSettings()
        }
        rebuildNavigation()
        updateHeader()
    }

    private fun rebuildNavigation() {
        if (!::bottomNavigation.isInitialized) return
        bottomNavigation.removeAllViews()
        Destination.entries.forEach { item ->
            val selected = item == destination
            val button = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                isFocusable = true
                background = rounded(
                    if (selected) elevated else surface,
                    dp(12),
                    if (selected) accent else surface
                )
                setPadding(0, dp(4), 0, dp(4))
                val icon = TextView(this@MainActivity).apply {
                    text = item.icon
                    gravity = Gravity.CENTER
                    textSize = 19f
                    setTextColor(if (selected) accent else secondary)
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                }
                addView(icon, LinearLayout.LayoutParams(-1, dp(26)))
                val title = TextView(this@MainActivity).apply {
                    text = item.label
                    gravity = Gravity.CENTER
                    textSize = 10f
                    setTextColor(if (selected) primary else secondary)
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                }
                addView(title, LinearLayout.LayoutParams(-1, dp(18)))
                isClickable = true
                isFocusable = true
                setOnClickListener { showDestination(item) }
                contentDescription = item.label
            }
            bottomNavigation.addView(button, LinearLayout.LayoutParams(0, -1, 1f).apply {
                marginStart = dp(3)
                marginEnd = dp(3)
            })
        }
    }

    private fun showDestination(value: Destination) {
        if (destination == value) return
        destination = value
        renderScreen()
    }

    private fun configureEdgeToEdge() {
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.TRANSPARENT
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.setDecorFitsSystemWindows(false)
            window.isStatusBarContrastEnforced = false
            window.isNavigationBarContrastEnforced = false
            val appearance = if (isDarkTheme) 0 else (
                android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                )
            window.insetsController?.setSystemBarsAppearance(
                appearance,
                android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            )
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or
                if (isDarkTheme) 0 else {
                    val lightStatus = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        lightStatus or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
                    } else lightStatus
                }
        }
    }

    private fun applyAppearance() {
        val systemIsDark =
            resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
        isDarkTheme = when (store.appearance) {
            AppearancePreference.LIGHT -> false
            AppearancePreference.DARK -> true
            AppearancePreference.SYSTEM -> systemIsDark
        }
        if (isDarkTheme) {
            appBackground = 0xFF07100F.toInt()
            surface = 0xFF101B19.toInt()
            elevated = 0xFF142420.toInt()
            border = 0xFF20352F.toInt()
            primary = 0xFFF2F7F4.toInt()
            secondary = 0xFF9AA9A3.toInt()
            accent = store.accentPreference.darkColor
            amber = 0xFFE0B873.toInt()
            danger = 0xFFE38E86.toInt()
        } else {
            appBackground = 0xFFF7F6F1.toInt()
            surface = 0xFFFBFAF7.toInt()
            elevated = 0xFFF1F0EA.toInt()
            border = 0xFFE1E0D9.toInt()
            primary = 0xFF202720.toInt()
            secondary = 0xFF737C74.toInt()
            accent = store.accentPreference.lightColor
            amber = 0xFF9A6B25.toInt()
            danger = 0xFFAA4845.toInt()
        }
    }

    private fun renderHome() {
        content.setPadding(dp(16), dp(14), dp(16), dp(18))
        content.addView(label("ENVIRONMENTAL MONITORING", 10f, secondary, true).apply {
            letterSpacing = 0.14f
            setPadding(dp(2), dp(4), 0, dp(4))
        })
        val deviceHeading = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(2), 0, 0, dp(10))
        }
        deviceHeading.addView(label(store.deviceName ?: "ESP32-SENSOR", 19f, primary, true),
            LinearLayout.LayoutParams(0, -2, 1f))
        homeDeviceStatus = label("", 10f, secondary, true).apply {
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = rounded(surface, dp(12), border)
        }
        deviceHeading.addView(homeDeviceStatus)
        content.addView(deviceHeading)

        val gaugeCard = surfacePanel(10)
        homeGauge = TemperatureGauge(this)
        gaugeCard.addView(homeGauge, LinearLayout.LayoutParams(-1, dp(226)))
        homeTemperatureHealth = label("", 10f, secondary).apply {
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(7))
        }
        gaugeCard.addView(homeTemperatureHealth)
        content.addView(gaugeCard, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(10)
        })

        val metricsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.TOP
        }
        val humidityCard = surfacePanel(12)
        humidityCard.addView(label("HUMIDITY", 10f, secondary, true).apply {
            letterSpacing = 0.08f
        })
        val humidityValueRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(8), 0, dp(2))
        }
        homeHumidity = label("--", 24f, primary).apply {
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        humidityValueRow.addView(homeHumidity)
        humidityValueRow.addView(label("% RH", 10f, secondary).apply {
            setPadding(dp(4), 0, 0, dp(3))
        })
        humidityCard.addView(humidityValueRow)
        homeHumidityHealth = label("", 9f, secondary)
        humidityCard.addView(homeHumidityHealth)
        metricsRow.addView(humidityCard, LinearLayout.LayoutParams(0, -1, 1f).apply {
            marginEnd = dp(5)
        })

        val healthCard = surfacePanel(12)
        healthCard.addView(label("SENSOR STATUS", 10f, secondary, true).apply {
            letterSpacing = 0.05f
        })
        homeAvailability = label("", 11f, secondary, true).apply {
            setPadding(0, dp(9), 0, dp(3))
            maxLines = 2
        }
        healthCard.addView(homeAvailability)
        healthCard.addView(label(preferredTransportLabel(), 9f, secondary).apply {
            setPadding(0, dp(3), 0, 0)
        })
        metricsRow.addView(healthCard, LinearLayout.LayoutParams(0, -1, 1f).apply {
            marginStart = dp(5)
        })
        content.addView(metricsRow, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(10)
        })

        homeExtras = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        homeVocValue = null
        homeVocHealth = null
        content.addView(homeExtras)

        val historyCard = surfacePanel(12)
        val historyHeading = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        historyHeading.addView(label("TEMPERATURE TREND", 10f, secondary, true),
            LinearLayout.LayoutParams(0, -2, 1f))
        homeRangeButtons.clear()
        timeRanges().forEach { (rangeLabel, duration) ->
            val button = rangeChip(rangeLabel, homeRangeMs == duration)
            homeRangeButtons[duration] = button
            historyHeading.addView(button, LinearLayout.LayoutParams(-2, dp(30)).apply {
                marginStart = dp(3)
            })
            button.setOnClickListener {
                homeRangeMs = duration
                homeRangeButtons.forEach { (range, view) -> styleRangeChip(view, range == duration) }
                updateSensorViews()
            }
        }
        historyCard.addView(historyHeading)
        homeGraph = HistoryGraph(this)
        configureGraph(homeGraph)
        historyCard.addView(homeGraph, LinearLayout.LayoutParams(-1, dp(158)).apply {
            topMargin = dp(7)
        })
        homeLastUpdate = label("No readings yet", 10f, secondary).apply {
            setPadding(0, dp(5), 0, 0)
        }
        historyCard.addView(homeLastUpdate)
        content.addView(historyCard, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(10)
            bottomMargin = dp(10)
        })

        val connected = connectionState in setOf(
            AndroidBluetoothManager.State.CONNECTED,
            AndroidBluetoothManager.State.RECEIVING
        )
        val action = if (connected) "Disconnect device" else "Connect saved device"
        content.addView(actionButton(action, connected.not()) {
            if (connected) {
                manuallyDisconnected = true
                bluetooth.disconnect()
                updateConnectionState(AndroidBluetoothManager.State.DISCONNECTED, "Disconnected by user")
            } else reconnectSavedDevice()
        }, LinearLayout.LayoutParams(-1, dp(46)))
        updateSensorViews()
    }

    private fun timeRanges(): List<Pair<String, Long>> = listOf(
        "1H" to 3_600_000L,
        "6H" to 21_600_000L,
        "24H" to 86_400_000L,
        "7D" to 604_800_000L
    )

    private fun renderDevices() {
        content.addView(sectionHeader("Devices", "Saved hardware and nearby Bluetooth devices"))
        val scanAction = actionButton("SCAN FOR BLE DEVICES", true) { startBleScan() }
        content.addView(scanAction, LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(17) })

        content.addView(sectionTitle("SAVED DEVICE"))
        val savedAddress = store.deviceAddress
        if (savedAddress == null) {
            content.addView(label("No saved device. Choose a paired device or scan for BLE below.", 12f, secondary).apply {
                setPadding(0, dp(6), 0, dp(14))
            })
        } else {
            addDeviceRow(
                store.deviceName ?: savedAddress,
                savedAddress,
                "${preferredTransportLabel()}  ·  ${statusDescription()}  ·  ${lastSeenDescription()}",
                if (connectionState in setOf(AndroidBluetoothManager.State.CONNECTED, AndroidBluetoothManager.State.RECEIVING)) "Disconnect" else "Connect",
                {
                    if (connectionState in setOf(AndroidBluetoothManager.State.CONNECTED, AndroidBluetoothManager.State.RECEIVING)) {
                        manuallyDisconnected = true
                        bluetooth.disconnect()
                        updateConnectionState(AndroidBluetoothManager.State.DISCONNECTED, "Disconnected by user")
                        renderScreen()
                    } else reconnectSavedDevice()
                }
            )
            addDeviceRowAction("Reconnect", "Rename", { reconnectSavedDevice() }, { showRenameDialog() })
            addDeviceRowAction("Remove saved device", "Remove", { removeSavedDevice() }, { removeSavedDevice() })
        }

        val sessions = store.loadConnectionEvents()
        if (sessions.isNotEmpty()) {
            content.addView(sectionTitle("RECENT CONNECTION"))
            sessions.takeLast(4).asReversed().forEach { event ->
                content.addView(label(
                    "${formatTimestamp(event.timestamp)} · ${event.state} · ${event.detail.take(70)}",
                    10f,
                    secondary
                ).apply { setPadding(0, dp(6), 0, dp(6)) })
            }
        }

        content.addView(sectionTitle("NEARBY BLE DEVICES"))
        if (discovered.isEmpty()) {
            content.addView(label("Scan to find nearby compatible sensors.", 11f, secondary).apply {
                setPadding(0, dp(5), 0, dp(10))
            })
        }
        discovered.values.forEach { (device, rssi) -> renderDiscoveredDevice(device, rssi) }

        content.addView(sectionTitle("PAIRED CLASSIC DEVICES"))
        val paired = try {
            bluetooth.bondedDevices()
        } catch (_: SecurityException) {
            emptyList()
        }
        if (paired.isEmpty()) {
            content.addView(label("No paired Bluetooth Classic devices.", 11f, secondary).apply {
                setPadding(0, dp(5), 0, dp(10))
            })
        } else {
            paired.forEach { device -> renderBondedDevice(device) }
        }
        content.addView(actionButton("OPEN ANDROID BLUETOOTH SETTINGS", false) {
            try {
                startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
            } catch (_: Exception) {
                showMessage("Open Android Settings and choose Bluetooth to pair your device.")
            }
        }, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(12) })
    }

    private fun renderDiscoveredDevice(device: BluetoothDevice, rssi: Int) {
        addDeviceRow(
            bluetoothDeviceName(device, "BLE device"),
            device.address,
            "BLE  ·  $rssi dBm",
            "Connect",
            { connectSelectedDevice(device, ConnectionMode.BLE) }
        )
    }

    private fun renderBondedDevice(device: BluetoothDevice) {
        addDeviceRow(
            bluetoothDeviceName(device, "Bluetooth device"),
            device.address,
            if (device.address == store.deviceAddress) "Saved  ·  Bluetooth Classic SPP" else "Paired  ·  Bluetooth Classic SPP",
            "Connect",
            { connectSelectedDevice(device, ConnectionMode.CLASSIC) }
        )
    }

    private fun renderAnalytics() {
        content.setPadding(dp(16), dp(14), dp(16), dp(18))
        content.addView(sectionHeader("Analytics", "Actual measurements from this device"))
        val rangeRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(7))
        }
        analyticsRangeButtons.clear()
        timeRanges().forEach { (label, duration) ->
            val button = rangeChip(label, analyticsRangeMs == duration)
            analyticsRangeButtons[duration] = button
            rangeRow.addView(button, LinearLayout.LayoutParams(0, dp(34), 1f).apply {
                marginEnd = dp(5)
            })
            button.setOnClickListener {
                analyticsRangeMs = duration
                analyticsRangeButtons.forEach { (range, view) ->
                    styleRangeChip(view, range == duration)
                }
                updateAnalyticsViews()
            }
        }
        content.addView(rangeRow)

        val temperatureCard = surfacePanel(12)
        temperatureCard.addView(label("TEMPERATURE", 10f, secondary, true).apply {
            letterSpacing = 0.08f
        })
        temperatureCard.addView(label(displayTemperatureUnit(), 9f, secondary).apply {
            setPadding(0, dp(2), 0, 0)
        })
        analyticsTemperatureGraph = HistoryGraph(this)
        configureGraph(analyticsTemperatureGraph)
        temperatureCard.addView(analyticsTemperatureGraph, LinearLayout.LayoutParams(-1, dp(164)).apply {
            topMargin = dp(3)
        })
        content.addView(temperatureCard, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(8)
        })

        val humidityCard = surfacePanel(12)
        humidityCard.addView(label("HUMIDITY", 10f, secondary, true).apply {
            letterSpacing = 0.08f
        })
        humidityCard.addView(label("% RH", 9f, secondary).apply {
            setPadding(0, dp(2), 0, 0)
        })
        analyticsHumidityGraph = HistoryGraph(this)
        analyticsHumidityGraph.configure(
            textColor = secondary,
            gridColor = border,
            lineColor = if (isDarkTheme) 0xFF52B6C2.toInt() else 0xFF347F88.toInt()
        )
        humidityCard.addView(analyticsHumidityGraph, LinearLayout.LayoutParams(-1, dp(164)).apply {
            topMargin = dp(3)
        })
        content.addView(humidityCard, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(8)
        })

        analyticsExtras = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        analyticsVocGraph = null
        content.addView(analyticsExtras)
        analyticsSummary = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }
        analyticsSummaryBindings.clear()
        analyticsSummary.addView(createAnalyticsMetricSummary(
            SensorKind.TEMPERATURE,
            "TEMPERATURE",
            displayTemperatureUnit()
        ), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        analyticsSummary.addView(createAnalyticsMetricSummary(
            SensorKind.HUMIDITY,
            "HUMIDITY",
            "% RH"
        ), LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(7) })
        if (history.any { it.kind == SensorKind.VOC_RAW }) {
            analyticsSummary.addView(createAnalyticsMetricSummary(SensorKind.VOC_RAW, "VOC RAW", "ticks"))
        }
        content.addView(analyticsSummary, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(2)
            bottomMargin = dp(10)
        })
        val actionRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actionRow.addView(actionButton("Export CSV", true) { exportCsv() },
            LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginEnd = dp(5) })
        actionRow.addView(actionButton("Clear history", false) {
            confirmClearHistory()
        }, LinearLayout.LayoutParams(0, dp(44), 1f).apply { marginStart = dp(5) })
        content.addView(actionRow)
        updateAnalyticsViews()
    }

    private fun rangeChip(text: String, selected: Boolean): TextView =
        label(text, 9f, if (selected) accent else secondary, selected).apply {
            gravity = Gravity.CENTER
            isClickable = true
            isFocusable = true
            background = rounded(if (selected) elevated else surface, dp(9), if (selected) accent else border)
            setPadding(dp(7), dp(4), dp(7), dp(4))
        }

    private fun styleRangeChip(view: TextView, selected: Boolean) {
        view.setTextColor(if (selected) accent else secondary)
        view.typeface = Typeface.create(
            if (selected) "sans-serif-medium" else "sans-serif",
            Typeface.NORMAL
        )
        view.background = rounded(
            if (selected) elevated else surface,
            dp(9),
            if (selected) accent else border
        )
    }

    private fun renderSettings() {
        content.setPadding(dp(16), dp(14), dp(16), dp(18))
        content.addView(sectionHeader("Settings", "Personalize your monitoring workspace"))

        content.addView(sectionTitle("APPEARANCE"))
        val appearanceGroup = surfacePanel(14)
        appearanceSpinner = spinner(
            AppearancePreference.entries.map { it.label },
            AppearancePreference.entries.indexOf(store.appearance)
        )
        appearanceGroup.addView(settingRow("Theme", "Light, dark, or follow system", appearanceSpinner))
        appearanceSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val preference = AppearancePreference.entries[position]
                if (store.appearance == preference) return
                store.appearance = preference
                applyAppearance()
                configureEdgeToEdge()
                if (::content.isInitialized) renderScreen()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        val accentSpinner = spinner(
            AccentPreference.entries.map { it.label },
            AccentPreference.entries.indexOf(store.accentPreference)
        )
        appearanceGroup.addView(settingRow("Accent color", "Interface highlight", accentSpinner))
        accentSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val preference = AccentPreference.entries[position]
                if (store.accentPreference == preference) return
                store.accentPreference = preference
                applyAppearance()
                if (::content.isInitialized) renderScreen()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        content.addView(appearanceGroup, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(8)
        })

        content.addView(sectionTitle("BLUETOOTH"))
        val bluetoothGroup = surfacePanel(14)
        val modeSpinner = spinner(
            ConnectionMode.entries.map { it.label },
            ConnectionMode.entries.indexOf(store.connectionMode)
        )
        bluetoothGroup.addView(settingRow("Preferred connection", "Classic SPP or BLE", modeSpinner))
        modeSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                store.connectionMode = ConnectionMode.entries[position]
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        val autoReconnect = Switch(this).apply {
            text = "Automatic reconnect"
            textSize = 12f
            setTextColor(primary)
            isChecked = store.autoReconnect
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                thumbTintList = android.content.res.ColorStateList.valueOf(accent)
                trackTintList = android.content.res.ColorStateList.valueOf(border)
            }
            setOnCheckedChangeListener { _, checked -> store.autoReconnect = checked }
        }
        bluetoothGroup.addView(settingRow("Automatic reconnect", "Retry the saved device while NEXORA is open", autoReconnect))
        content.addView(bluetoothGroup, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(8)
        })

        content.addView(sectionTitle("SENSORS"))
        val sensorsGroup = surfacePanel(14)
        val unitSpinner = spinner(
            listOf("Celsius (°C)", "Fahrenheit (°F)"),
            if (store.temperatureUnit == "°F") 1 else 0
        )
        sensorsGroup.addView(settingRow("Temperature unit", "Display preference", unitSpinner))
        unitSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                val unit = if (position == 1) "°F" else "°C"
                if (store.temperatureUnit == unit) return
                store.temperatureUnit = unit
                if (::content.isInitialized) renderScreen()
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        val intervals = listOf(1_000, 2_000, 5_000, 10_000)
        val intervalSpinner = spinner(
            intervals.map { "${it / 1000} s" },
            intervals.indexOf(store.samplingIntervalMs).takeIf { it >= 0 } ?: 1
        )
        sensorsGroup.addView(settingRow("Sampling interval", "BLE characteristics that require polling", intervalSpinner))
        intervalSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                store.samplingIntervalMs = intervals[position]
            }
            override fun onNothingSelected(parent: AdapterView<*>?) = Unit
        }
        content.addView(sensorsGroup, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(8)
        })

        content.addView(sectionTitle("DEVICE PROFILE"))
        val profileGroup = surfacePanel(14)
        profileGroup.addView(label(
            "Configure the BLE UUIDs used by your firmware. The Bluetooth SIG environmental profile is also checked.",
            11f,
            secondary
        ).apply { setPadding(0, dp(3), 0, dp(8)) })
        val savedProfile = store.bleProfile
        val serviceInput = textInput("Service UUID", savedProfile.serviceUuid)
        val temperatureInput = textInput("Temperature characteristic UUID", savedProfile.temperatureUuid)
        val humidityInput = textInput("Humidity characteristic UUID", savedProfile.humidityUuid)
        val vocInput = textInput("Optional raw VOC characteristic UUID", savedProfile.vocUuid)
        listOf(serviceInput, temperatureInput, humidityInput, vocInput).forEach { input ->
            profileGroup.addView(input, LinearLayout.LayoutParams(-1, dp(44)).apply { bottomMargin = dp(7) })
        }
        profileGroup.addView(actionButton("Save BLE profile", false) {
            val candidate = BleProfile(
                serviceInput.text.toString().trim(),
                temperatureInput.text.toString().trim(),
                humidityInput.text.toString().trim(),
                vocInput.text.toString().trim()
            )
            try {
                AndroidBluetoothManager.uuidFrom(candidate.serviceUuid)
                AndroidBluetoothManager.uuidFrom(candidate.temperatureUuid)
                AndroidBluetoothManager.uuidFrom(candidate.humidityUuid)
                if (candidate.vocUuid.isNotBlank()) AndroidBluetoothManager.uuidFrom(candidate.vocUuid)
                store.bleProfile = candidate
                showMessage("BLE profile saved on this device.")
            } catch (_: IllegalArgumentException) {
                showMessage("Enter valid 16-bit, 32-bit, or 128-bit Bluetooth UUIDs.")
            }
        }, LinearLayout.LayoutParams(-1, dp(42)).apply { topMargin = dp(4) })
        content.addView(profileGroup, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(8)
        })

        content.addView(sectionTitle("DATA AND ABOUT"))
        val aboutGroup = surfacePanel(14)
        aboutGroup.addView(label(
            "NEXORA · Smart IoT Monitoring Platform",
            11f,
            secondary
        ).apply { setPadding(0, dp(3), 0, dp(8)) })
        aboutGroup.addView(label(
            "${history.size} readings stored locally on this phone. No cloud telemetry is used.",
            11f,
            secondary
        ).apply { setPadding(0, dp(5), 0, dp(12)) })
        aboutGroup.addView(actionButton("Export history as CSV", false) { exportCsv() },
            LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(7) })
        aboutGroup.addView(actionButton("Clear local history", false) { confirmClearHistory() },
            LinearLayout.LayoutParams(-1, dp(42)).apply { bottomMargin = dp(12) })
        aboutGroup.addView(label("NEXORA  ·  Android  ·  Version ${BuildConfig.VERSION_NAME}", 11f, secondary).apply {
            setPadding(0, dp(8), 0, dp(3))
        })
        aboutGroup.addView(label("CONNECT. MONITOR. CONTROL.", 10f, secondary, true).apply {
            letterSpacing = 0.06f
        })
        content.addView(aboutGroup, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(8)
        })
    }

    private fun settingRow(title: String, description: String, trailing: View): LinearLayout {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(9), 0, dp(9))
        }
        val text = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        text.addView(label(title, 13f, primary))
        text.addView(label(description, 10f, secondary).apply { setPadding(0, dp(3), 0, 0) })
        row.addView(text, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(trailing)
        return row
    }

    private fun addDeviceRow(
        name: String,
        identity: String,
        details: String,
        action: String,
        onAction: () -> Unit
    ) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = rounded(surface, dp(14), border)
        }
        val detailsColumn = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        detailsColumn.addView(label(name, 14f, primary, true).apply { maxLines = 1 })
        detailsColumn.addView(label(identity, 10f, secondary).apply {
            setPadding(0, dp(2), 0, 0)
            maxLines = 1
        })
        detailsColumn.addView(label(details, 10f, secondary).apply {
            setPadding(0, dp(4), 0, 0)
            maxLines = 2
        })
        row.addView(detailsColumn, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(actionButton(action, action.equals("Connect", true), onAction),
            LinearLayout.LayoutParams(dp(94), dp(38)).apply { marginStart = dp(8) })
        content.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(7)
        })
    }

    private fun addDeviceRowAction(
        firstLabel: String,
        secondLabel: String,
        firstAction: () -> Unit,
        secondAction: () -> Unit
    ) {
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        actions.addView(actionButton(firstLabel, false, firstAction),
            LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginEnd = dp(4) })
        actions.addView(actionButton(secondLabel, false, secondAction),
            LinearLayout.LayoutParams(0, dp(38), 1f).apply { marginStart = dp(4) })
        content.addView(actions, LinearLayout.LayoutParams(-1, dp(42)))
    }

    private fun lastSeenDescription(): String {
        val latest = latestReadings.values.maxByOrNull { it.timestamp }
        return latest?.let { "Last seen ${formatRelative(it.timestamp)}" } ?: "No sensor readings yet"
    }

    @SuppressLint("MissingPermission")
    private fun bluetoothDeviceName(device: BluetoothDevice, fallback: String): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            !hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) return fallback
        return try {
            device.name?.takeIf { it.isNotBlank() } ?: fallback
        } catch (_: SecurityException) {
            fallback
        }
    }

    private fun preferredTransportLabel(): String = when (store.connectionMode) {
        ConnectionMode.AUTOMATIC -> store.lastTransport.label
        else -> store.connectionMode.label
    }

    private fun addDivider(parent: LinearLayout, topMargin: Int = 0) {
        parent.addView(View(this).apply { setBackgroundColor(border) },
            LinearLayout.LayoutParams(-1, dp(1)).apply { this.topMargin = topMargin })
    }

    private fun configureGraph(graph: HistoryGraph) {
        graph.configure(textColor = secondary, gridColor = border, lineColor = accent)
    }

    private fun sectionHeader(title: String, subtitle: String): View {
        val block = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        block.addView(label(title, 23f, primary).apply {
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setPadding(0, 0, 0, dp(2))
        })
        block.addView(label(subtitle, 11f, secondary).apply { setPadding(0, dp(1), 0, dp(12)) })
        return block
    }

    private fun sectionTitle(title: String): TextView =
        label(title, 10f, secondary, true).apply {
            letterSpacing = 0.1f
            setPadding(0, dp(13), 0, dp(6))
        }

    private fun panel(title: String): LinearLayout {
        val container = surfacePanel(12)
        container.addView(label(title, 10f, secondary, true).apply {
            letterSpacing = 0.1f
            setPadding(0, 0, 0, dp(6))
        })
        return container
    }

    private fun surfacePanel(padding: Int): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(padding), dp(padding), dp(padding), dp(padding))
            background = rounded(surface, dp(14), border)
        }

    private fun actionButton(title: String, primaryAction: Boolean, action: () -> Unit): Button =
        Button(this).apply {
            text = title
            textSize = 11f
            isAllCaps = false
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            setTextColor(if (primaryAction) Color.WHITE else accent)
            letterSpacing = 0.04f
            background = rounded(if (primaryAction) accent else surface, dp(12), if (primaryAction) accent else border)
            minHeight = 0
            minimumHeight = 0
            setPadding(dp(8), dp(4), dp(8), dp(4))
            setOnClickListener { action() }
        }

    private fun label(textValue: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            text = textValue
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }

    private fun spinner(values: List<String>, selected: Int): Spinner {
        val adapter = object : ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, values) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View =
                themedSpinnerLabel(getItem(position).orEmpty(), convertView, true)

            override fun getDropDownView(position: Int, convertView: View?, parent: android.view.ViewGroup): View =
                themedSpinnerLabel(getItem(position).orEmpty(), convertView, false).apply {
                    setPadding(dp(12), dp(10), dp(12), dp(10))
                }
        }
        return Spinner(this).apply {
            this.adapter = adapter
            setSelection(selected.coerceIn(values.indices))
            background = rounded(surface, dp(12), border)
            setPadding(dp(8), 0, dp(8), 0)
        }
    }

    private fun themedSpinnerLabel(
        value: String,
        convertView: View?,
        showDisclosure: Boolean
    ): View = (convertView as? TextView ?: TextView(this)).apply {
        text = if (showDisclosure) "$value    ▾" else value
        textSize = 11f
        setTextColor(primary)
        gravity = Gravity.CENTER_VERTICAL
        typeface = Typeface.create("sans-serif", Typeface.NORMAL)
        setPadding(dp(8), dp(8), dp(8), dp(8))
    }

    private fun textInput(hintText: String, value: String): EditText =
        EditText(this).apply {
            hint = hintText
            setText(value)
            textSize = 12f
            setTextColor(primary)
            setHintTextColor(secondary)
            setSingleLine(true)
            setPadding(dp(10), 0, dp(10), 0)
            background = rounded(surface, dp(2), border)
        }

    private fun rounded(color: Int, radius: Int, stroke: Int): GradientDrawable =
        GradientDrawable().apply {
            setColor(color)
            cornerRadius = radius.toFloat()
            setStroke(dp(1), stroke)
        }

    private fun updateHeader() {
        if (!::statusLabel.isInitialized) return
        selectedDeviceLabel.text = store.deviceName ?: "ESP32-SENSOR"
        val (text, color) = when (connectionState) {
            AndroidBluetoothManager.State.DISCONNECTED -> "Offline" to secondary
            AndroidBluetoothManager.State.SCANNING -> "Scanning" to amber
            AndroidBluetoothManager.State.CONNECTING -> "Connecting" to amber
            AndroidBluetoothManager.State.CONNECTED -> "Connected" to amber
            AndroidBluetoothManager.State.RECEIVING -> if (latestReadings.values.any { isFresh(it) }) {
                "Receiving" to accent
            } else "Stale" to amber
            AndroidBluetoothManager.State.ERROR -> "Connection error" to danger
        }
        statusLabel.setTextColor(color)
        statusDetail.text = "  $text"
        statusDetail.setTextColor(color)
        if (::homeDeviceStatus.isInitialized) {
            homeDeviceStatus.text = statusDescription()
            homeDeviceStatus.setTextColor(color)
        }
        if (destination == Destination.HOME && ::homeGauge.isInitialized) updateSensorViews()
    }

    private fun onBluetoothState(state: AndroidBluetoothManager.State, detail: String) {
        val previous = connectionState
        connectionState = state
        connectionDetail = detail
        if (state != previous && state in setOf(
                AndroidBluetoothManager.State.CONNECTED,
                AndroidBluetoothManager.State.RECEIVING,
                AndroidBluetoothManager.State.DISCONNECTED,
                AndroidBluetoothManager.State.ERROR
            )) {
            store.recordConnectionEvent(ConnectionEvent(state.name, detail, System.currentTimeMillis()))
        }
        if (state == AndroidBluetoothManager.State.DISCONNECTED ||
            state == AndroidBluetoothManager.State.ERROR) {
            if (!manuallyDisconnected && (previous == AndroidBluetoothManager.State.CONNECTED ||
                previous == AndroidBluetoothManager.State.RECEIVING ||
                previous == AndroidBluetoothManager.State.CONNECTING)) {
                scheduleAutoReconnect()
            }
        }
        updateHeader()
        if (state != previous && ::content.isInitialized && destination == Destination.DEVICES) renderScreen()
    }

    private fun updateConnectionState(state: AndroidBluetoothManager.State, detail: String) {
        connectionState = state
        connectionDetail = detail
        updateHeader()
    }

    private fun acceptReading(reading: SensorReading) {
        val previous = latestReadings[reading.kind]
        if (previous != null && previous.value == reading.value && reading.timestamp - previous.timestamp < 150) return
        latestReadings[reading.kind] = reading
        history.add(reading)
        if (history.size > NexoraDataStore.MAX_HISTORY) history.removeAt(0)
        queueHistorySave()
        retryCount = 0
        if (connectionState != AndroidBluetoothManager.State.RECEIVING) {
            connectionState = AndroidBluetoothManager.State.RECEIVING
        }
        updateHeader()
        updateAnalyticsViews()
    }

    private fun updateSensorViews() {
        if (destination != Destination.HOME || !::homeGauge.isInitialized) return
        val temperature = latestReadings[SensorKind.TEMPERATURE]
        val humidity = latestReadings[SensorKind.HUMIDITY]
        val voc = latestReadings[SensorKind.VOC_RAW]
        homeGauge.render(
            celsius = temperature?.value,
            formattedValue = temperature?.let { formatTemperature(it.value) } ?: "--",
            unit = displayTemperatureUnit(),
            primaryColor = primary,
            secondaryColor = secondary,
            trackColor = border,
            accentColor = accent
        )
        homeHumidity.text = humidity?.let { String.format(Locale.getDefault(), "%.2f", it.value) } ?: "--"
        setHealth(homeTemperatureHealth, temperature)
        setHealth(homeHumidityHealth, humidity)
        if (voc == null) {
            homeExtras.removeAllViews()
            homeVocValue = null
            homeVocHealth = null
        } else {
            if (homeVocValue == null || homeVocHealth == null) {
                val vocCard = panel("SGP40 · RAW VOC SIGNAL")
                val valueView = label("-- ticks", 22f, primary, true)
                val healthView = label("", 10f, secondary)
                homeVocValue = valueView
                homeVocHealth = healthView
                vocCard.addView(valueView)
                vocCard.addView(healthView.apply { setPadding(0, dp(4), 0, 0) })
                homeExtras.removeAllViews()
                homeExtras.addView(vocCard, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
            }
            homeVocValue?.text = String.format(Locale.getDefault(), "%.0f ticks", voc.value)
            homeVocHealth?.let { setHealth(it, voc) }
        }
        val latest = listOfNotNull(temperature, humidity).maxByOrNull { it.timestamp }
        homeLastUpdate.text = latest?.let(::formatHomeUpdate) ?: "No readings yet"
        val receivingFreshData = connectionState == AndroidBluetoothManager.State.RECEIVING &&
            latestReadings.values.any { isFresh(it) }
        homeAvailability.text = when {
            receivingFreshData -> "Receiving data"
            connectionState == AndroidBluetoothManager.State.CONNECTED ||
                connectionState == AndroidBluetoothManager.State.RECEIVING ->
                "Connected · waiting"
            latest != null -> "Last reading saved"
            else -> "No reading yet"
        }
        homeAvailability.setTextColor(if (receivingFreshData) accent else secondary)
        val temperatureHistory = history.filter { it.kind == SensorKind.TEMPERATURE }.map {
            if (store.temperatureUnit == "°F") it.copy(value = it.value * 9.0 / 5.0 + 32.0) else it
        }
        homeGraph.render(temperatureHistory, homeRangeMs, displayTemperatureUnit())
    }

    private fun setHealth(view: TextView, reading: SensorReading?) {
        if (reading == null) {
            view.text = if (connectionState == AndroidBluetoothManager.State.ERROR) "Error · unavailable" else "Waiting for sensor data"
            view.setTextColor(if (connectionState == AndroidBluetoothManager.State.ERROR) danger else secondary)
        } else if (connectionState != AndroidBluetoothManager.State.RECEIVING || !isFresh(reading)) {
            view.text = "Stale · last ${formatRelative(reading.timestamp)}"
            view.setTextColor(amber)
        } else {
            view.text = "Healthy · ${formatRelative(reading.timestamp)}"
            view.setTextColor(accent)
        }
    }

    private fun updateAnalyticsViews() {
        if (!::analyticsTemperatureGraph.isInitialized || destination != Destination.ANALYTICS) return
        val tempReadings = history.filter {
            it.kind == SensorKind.TEMPERATURE && it.timestamp >= System.currentTimeMillis() - analyticsRangeMs
        }.map { if (store.temperatureUnit == "°F") it.copy(value = it.value * 9.0 / 5.0 + 32.0) else it }
        val humidityReadings = history.filter {
            it.kind == SensorKind.HUMIDITY && it.timestamp >= System.currentTimeMillis() - analyticsRangeMs
        }
        val vocReadings = history.filter {
            it.kind == SensorKind.VOC_RAW && it.timestamp >= System.currentTimeMillis() - analyticsRangeMs
        }
        analyticsTemperatureGraph.render(tempReadings, analyticsRangeMs, displayTemperatureUnit())
        analyticsHumidityGraph.render(humidityReadings, analyticsRangeMs, "% RH")
        if (history.any { it.kind == SensorKind.VOC_RAW }) {
            if (analyticsVocGraph == null) {
                val card = surfacePanel(12)
                card.addView(label("VOC RAW SIGNAL", 10f, secondary, true))
                card.addView(label("ticks", 9f, secondary).apply { setPadding(0, dp(2), 0, 0) })
                val graph = HistoryGraph(this)
                configureGraph(graph)
                analyticsVocGraph = graph
                card.addView(graph, LinearLayout.LayoutParams(-1, dp(145)).apply {
                    topMargin = dp(3)
                })
                analyticsExtras.addView(card, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
            }
            analyticsVocGraph?.render(vocReadings, analyticsRangeMs, "ticks")
        }
        updateAnalyticsMetricSummary(SensorKind.TEMPERATURE, tempReadings.map { it.value })
        updateAnalyticsMetricSummary(SensorKind.HUMIDITY, humidityReadings.map { it.value })
        if (history.any { it.kind == SensorKind.VOC_RAW }) {
            if (SensorKind.VOC_RAW !in analyticsSummaryBindings) {
                analyticsSummary.addView(createAnalyticsMetricSummary(SensorKind.VOC_RAW, "VOC RAW", "ticks"))
            }
            updateAnalyticsMetricSummary(SensorKind.VOC_RAW, vocReadings.map { it.value })
        }
    }

    private fun createAnalyticsMetricSummary(kind: SensorKind, title: String, unit: String): View {
        val card = surfacePanel(11)
        card.addView(label(title, 9f, secondary, true).apply {
            letterSpacing = 0.06f
            setPadding(0, 0, 0, dp(8))
        })
        val metrics = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val values = mutableListOf<TextView>()
        listOf("MIN", "MAX", "AVG").forEachIndexed { index, caption ->
            val column = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
            }
            column.addView(label(caption, 8f, secondary, true))
            val valueView = label("-- $unit", 13f, primary, true).apply {
                setPadding(0, dp(3), 0, 0)
                maxLines = 1
            }
            values.add(valueView)
            column.addView(valueView)
            metrics.addView(column, LinearLayout.LayoutParams(0, -2, 1f).apply {
                if (index > 0) marginStart = dp(6)
            })
        }
        card.addView(metrics)
        analyticsSummaryBindings[kind] = AnalyticsSummaryBinding(values, unit)
        return card
    }

    private fun updateAnalyticsMetricSummary(kind: SensorKind, values: List<Double>) {
        val binding = analyticsSummaryBindings[kind] ?: return
        val statistics = listOf(values.minOrNull(), values.maxOrNull(), values.average().takeIf { values.isNotEmpty() })
        binding.values.forEachIndexed { index, view ->
            val reading = statistics[index]
            val formatted = reading?.let { String.format(Locale.getDefault(), "%.1f", it) } ?: "--"
            view.text = "$formatted ${binding.unit}"
        }
    }

    private fun displayTemperatureUnit(): String = if (store.temperatureUnit == "°F") "°F" else "°C"

    private fun formatTemperature(celsius: Double): String {
        val value = if (store.temperatureUnit == "°F") celsius * 9.0 / 5.0 + 32.0 else celsius
        return String.format(Locale.getDefault(), "%.2f", value)
    }

    private fun isFresh(reading: SensorReading): Boolean =
        System.currentTimeMillis() - reading.timestamp <= STALE_AFTER_MS

    private fun statusDescription(): String = when (connectionState) {
        AndroidBluetoothManager.State.DISCONNECTED -> "Disconnected"
        AndroidBluetoothManager.State.SCANNING -> "Scanning"
        AndroidBluetoothManager.State.CONNECTING -> "Connecting"
        AndroidBluetoothManager.State.CONNECTED -> "Connected, waiting for data"
        AndroidBluetoothManager.State.RECEIVING -> if (latestReadings.values.any { isFresh(it) }) "Receiving data" else "Stale data"
        AndroidBluetoothManager.State.ERROR -> "Error"
    }

    private fun refreshStatusTicker() {
        val refresh = object : Runnable {
            override fun run() {
                if (isFinishing || isDestroyed) return
                updateHeader()
                if (destination == Destination.HOME && ::homeLastUpdate.isInitialized) {
                    latestReadings.values.maxByOrNull { it.timestamp }?.let {
                        homeLastUpdate.text = formatHomeUpdate(it)
                    }
                }
                updateAnalyticsViews()
                handler.postDelayed(this, 1000)
            }
        }
        screenRefresh = refresh
        handler.post(refresh)
    }

    private fun startBleScan() {
        if (!ensureBluetoothPermission(forScan = true)) return
        discovered.clear()
        renderScreen()
        bluetooth.startBleScan(store.bleProfile)
    }

    private fun reconnectSavedDevice() {
        val address = store.deviceAddress
        if (address == null) {
            showDestination(Destination.DEVICES)
            showMessage("Add a device first.")
            return
        }
        if (!ensureBluetoothPermission(forScan = false)) {
            pendingSavedReconnect = true
            return
        }
        val preferred = store.connectionMode
        val transport = if (preferred != ConnectionMode.AUTOMATIC) preferred else store.lastTransport
        val selected = if (transport != ConnectionMode.AUTOMATIC) transport else {
            val paired = try {
                bluetooth.bondedDevices().any { it.address == address }
            } catch (_: SecurityException) {
                false
            }
            if (paired) ConnectionMode.CLASSIC else ConnectionMode.BLE
        }
        activeTransport = selected
        manuallyDisconnected = false
        connectionDetail = "Reconnecting to saved device"
        updateConnectionState(AndroidBluetoothManager.State.CONNECTING, connectionDetail)
        bluetooth.connectSaved(address, selected, store.bleProfile, store.samplingIntervalMs)
    }

    private fun saveAndConnect(device: BluetoothDevice, mode: ConnectionMode) {
        val name = try {
            device.name
        } catch (_: SecurityException) {
            null
        }
        store.deviceAddress = device.address
        store.deviceName = name?.takeIf { it.isNotBlank() } ?: "ESP32 device"
        store.lastTransport = mode
        activeTransport = mode
        manuallyDisconnected = false
        retryCount = 0
        val preferred = store.connectionMode
        if (preferred == ConnectionMode.AUTOMATIC) store.lastTransport = mode
        when (mode) {
            ConnectionMode.CLASSIC -> bluetooth.connectClassic(device)
            ConnectionMode.BLE -> bluetooth.connectBle(device, store.bleProfile, store.samplingIntervalMs)
            ConnectionMode.AUTOMATIC -> Unit
        }
        renderScreen()
    }

    private fun connectSelectedDevice(device: BluetoothDevice, mode: ConnectionMode) {
        if (Build.VERSION.SDK_INT >= 31 && !hasPermission(Manifest.permission.BLUETOOTH_CONNECT)) {
            pendingClassicDevice = device
            activeTransport = mode
            requestPermissions(arrayOf(Manifest.permission.BLUETOOTH_CONNECT), REQUEST_CONNECT_PERMISSION)
            return
        }
        saveAndConnect(device, mode)
    }

    private fun scheduleAutoReconnect(delayMs: Long? = null) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
            !hasPermission(Manifest.permission.BLUETOOTH_CONNECT)
        ) return
        if (manuallyDisconnected || !store.autoReconnect || store.deviceAddress == null || retryCount >= MAX_RETRIES) return
        val delay = delayMs ?: RETRY_DELAYS[retryCount.coerceIn(RETRY_DELAYS.indices)]
        val now = SystemClock.elapsedRealtime()
        if (now < lastRetryAt) return
        lastRetryAt = now + delay
        handler.postDelayed({
            if (isFinishing || manuallyDisconnected || !store.autoReconnect || store.deviceAddress == null ||
                connectionState in setOf(
                    AndroidBluetoothManager.State.CONNECTING,
                    AndroidBluetoothManager.State.CONNECTED,
                    AndroidBluetoothManager.State.RECEIVING,
                    AndroidBluetoothManager.State.SCANNING
                )) return@postDelayed
            if (!bluetooth.isBluetoothEnabled()) {
                connectionDetail = "Bluetooth is disabled"
                updateHeader()
                return@postDelayed
            }
            retryCount += 1
            reconnectSavedDevice()
        }, delay)
    }

    private fun ensureBluetoothPermission(forScan: Boolean): Boolean {
        val permissions = if (Build.VERSION.SDK_INT >= 31) {
            if (forScan) arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
            else arrayOf(Manifest.permission.BLUETOOTH_CONNECT)
        } else if (forScan) {
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)
        } else {
            emptyArray()
        }
        val missing = permissions.filterNot(::hasPermission)
        if (missing.isEmpty()) return true
        pendingScanPermission = forScan
        requestPermissions(missing.toTypedArray(), if (forScan) REQUEST_SCAN_PERMISSION else REQUEST_CONNECT_PERMISSION)
        return false
    }

    private fun hasPermission(permission: String): Boolean =
        Build.VERSION.SDK_INT < 23 || checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED

    @Deprecated("Deprecated in Android 13")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQUEST_CONNECT_PERMISSION && requestCode != REQUEST_SCAN_PERMISSION) return
        val granted = grantResults.isNotEmpty() && grantResults.all { it == PackageManager.PERMISSION_GRANTED }
        if (!granted) {
            connectionDetail = "Bluetooth permission required"
            updateConnectionState(AndroidBluetoothManager.State.ERROR, connectionDetail)
            showMessage("Grant Bluetooth permission in Android app settings to connect.")
            return
        }
        if (requestCode == REQUEST_SCAN_PERMISSION && pendingScanPermission) {
            pendingScanPermission = false
            startBleScan()
        } else {
            val selectedDevice = pendingClassicDevice
            pendingClassicDevice = null
            if (selectedDevice != null) {
                saveAndConnect(selectedDevice, activeTransport)
            } else if (pendingSavedReconnect) {
                pendingSavedReconnect = false
                reconnectSavedDevice()
            } else if (store.deviceAddress != null && store.autoReconnect) {
                reconnectSavedDevice()
            } else {
                updateConnectionState(
                    AndroidBluetoothManager.State.DISCONNECTED,
                    "Bluetooth permission granted"
                )
            }
        }
    }

    private fun showRenameDialog() {
        val input = EditText(this).apply {
            setText(store.deviceName.orEmpty())
            setSelection(text.length)
            setPadding(dp(16), dp(8), dp(16), dp(8))
        }
        android.app.AlertDialog.Builder(this)
            .setTitle("Rename device")
            .setView(input)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                val value = input.text.toString().trim()
                if (value.isNotEmpty()) {
                    store.deviceName = value.take(50)
                    renderScreen()
                }
            }
            .show()
    }

    private fun removeSavedDevice() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Remove saved device?")
            .setMessage("This removes the device identity and connection preference from this phone. Local history remains.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Remove") { _, _ ->
                bluetooth.disconnect()
                store.deviceAddress = null
                store.deviceName = null
                store.connectionMode = ConnectionMode.AUTOMATIC
                store.lastTransport = ConnectionMode.AUTOMATIC
                activeTransport = ConnectionMode.AUTOMATIC
                updateConnectionState(AndroidBluetoothManager.State.DISCONNECTED, "Saved device removed")
                renderScreen()
            }
            .show()
    }

    private fun confirmClearHistory() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Clear local history?")
            .setMessage("This permanently removes the sensor readings stored on this phone.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear") { _, _ ->
                history.clear()
                latestReadings.clear()
                historySave?.let(handler::removeCallbacks)
                historySave = null
                storageExecutor.execute { store.clearReadings() }
                updateSensorViews()
                updateAnalyticsViews()
                renderScreen()
            }
            .show()
    }

    private fun exportCsv() {
        if (history.isEmpty()) {
            showMessage("No stored readings to export.")
            return
        }
        requestedExport = buildString {
            appendLine("Timestamp,Device,Sensor,Value,Unit")
            history.forEach { reading ->
                val name = (store.deviceName ?: "ESP32 device").replace("\"", "\"\"")
                val value = if (reading.kind == SensorKind.TEMPERATURE && store.temperatureUnit == "°F") {
                    reading.value * 9.0 / 5.0 + 32.0
                } else reading.value
                val unit = if (reading.kind == SensorKind.TEMPERATURE) displayTemperatureUnit() else reading.kind.unit
                appendLine(
                    "${formatIso(reading.timestamp)},\"$name\",${reading.kind.label},${"%.2f".format(Locale.US, value)},$unit"
                )
            }
        }
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "nexora_sensor_history.csv")
        }
        @Suppress("DEPRECATION")
        startActivityForResult(intent, REQUEST_EXPORT)
    }

    @Deprecated("Deprecated in Android 11")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQUEST_EXPORT || resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use {
                it.write(requestedExport.orEmpty())
            } ?: throw IllegalStateException("Could not open the selected export location.")
            showMessage("CSV exported.")
        } catch (exception: Exception) {
            showMessage("CSV export failed: ${exception.message ?: "storage error"}")
        } finally {
            requestedExport = null
        }
    }

    private fun formatTimestamp(timestamp: Long): String =
        SimpleDateFormat("MMM d, HH:mm:ss", Locale.getDefault()).format(Date(timestamp))

    private fun formatHomeUpdate(reading: SensorReading): String {
        val datePattern = if (android.text.format.DateUtils.isToday(reading.timestamp)) {
            "HH:mm"
        } else {
            "MMM d, HH:mm"
        }
        val time = SimpleDateFormat(datePattern, Locale.getDefault()).format(Date(reading.timestamp))
        return "Updated ${formatRelative(reading.timestamp)} · $time"
    }

    private fun formatIso(timestamp: Long): String =
        SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.US).format(Date(timestamp))

    private fun formatRelative(timestamp: Long): String {
        val seconds = ((System.currentTimeMillis() - timestamp).coerceAtLeast(0)) / 1000
        return when {
            seconds < 2 -> "just now"
            seconds < 60 -> "${seconds}s ago"
            seconds < 3600 -> "${seconds / 60}m ago"
            else -> "${seconds / 3600}h ago"
        }
    }

    private fun showMessage(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun queueHistorySave() {
        historySave?.let(handler::removeCallbacks)
        val save = Runnable {
            historySave = null
            persistHistory()
        }
        historySave = save
        handler.postDelayed(save, HISTORY_SAVE_DELAY_MS)
    }

    private fun persistHistory() {
        if (!historyLoaded) return
        val snapshot = history.toList()
        storageExecutor.execute { store.saveReadings(snapshot) }
    }

    private fun loadStoredHistory() {
        storageExecutor.execute {
            val savedReadings = store.loadReadings()
            handler.post {
                if (isFinishing || isDestroyed) return@post
                val liveReadings = history.toList()
                history.addAll(savedReadings)
                history.sortBy { it.timestamp }
                if (history.size > NexoraDataStore.MAX_HISTORY) {
                    history.subList(0, history.size - NexoraDataStore.MAX_HISTORY).clear()
                }
                latestReadings.clear()
                history.forEach { reading ->
                    if ((latestReadings[reading.kind]?.timestamp ?: 0L) < reading.timestamp) {
                        latestReadings[reading.kind] = reading
                    }
                }
                historyLoaded = true
                if (liveReadings.isNotEmpty()) persistHistory()
                updateHeader()
                updateAnalyticsViews()
            }
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val STALE_AFTER_MS = 15_000L
        private const val MAX_RETRIES = 3
        private const val REQUEST_CONNECT_PERMISSION = 501
        private const val REQUEST_SCAN_PERMISSION = 502
        private const val REQUEST_EXPORT = 20
        private const val HISTORY_SAVE_DELAY_MS = 1_000L
        private val RETRY_DELAYS = longArrayOf(1_500, 4_000, 10_000)
    }
}
