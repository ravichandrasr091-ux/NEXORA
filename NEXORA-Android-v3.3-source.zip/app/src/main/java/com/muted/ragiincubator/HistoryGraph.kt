package com.muted.ragiincubator

import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.view.View
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class HistoryGraph(context: Context) : View(context) {
    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE1E0D9.toInt(); strokeWidth = dp(1f) }
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF315B45.toInt()
        strokeWidth = dp(1.8f)
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF737C74.toInt()
        textSize = dp(9f)
    }
    private val pointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF315B45.toInt() }
    private val path = Path()
    private val fillPath = Path()
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private var points: List<SensorReading> = emptyList()
    private var rangeMs = 60_000L
    private var unit = "°C"
    private var emptyText = "No readings in this period"

    fun configure(textColor: Int, gridColor: Int, lineColor: Int) {
        textPaint.color = textColor
        gridPaint.color = gridColor
        linePaint.color = lineColor
        pointPaint.color = lineColor
        fillPaint.color = lineColor
        invalidate()
    }

    fun render(readings: List<SensorReading>, selectedRangeMs: Long, measurementUnit: String) {
        points = readings
        rangeMs = selectedRangeMs
        unit = measurementUnit
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val left = dp(43f)
        val right = width - dp(8f)
        val top = dp(18f)
        val bottom = height - dp(26f)
        if (right <= left || bottom <= top) return
        for (row in 0..2) {
            val y = top + row * (bottom - top) / 2f
            canvas.drawLine(left, y, right, y, gridPaint)
        }
        val now = System.currentTimeMillis()
        val visible = points.filter { it.timestamp >= now - rangeMs && it.timestamp <= now }
        if (visible.isEmpty()) {
            val message = if (points.isEmpty()) "No sensor history yet" else emptyText
            canvas.drawText(message, left, (top + bottom) / 2f, textPaint)
            drawTimeLabels(canvas, left, right, now)
            return
        }
        val minValue = visible.minOf { it.value }
        val maxValue = visible.maxOf { it.value }
        val pad = maxOf((maxValue - minValue) * 0.12, if (unit == "% RH") 0.5 else 0.1)
        val low = minValue - pad
        val span = maxOf((maxValue - minValue) + pad * 2, 0.01)
        canvas.drawText(unit, dp(2f), top + dp(4f), textPaint)
        canvas.drawText(String.format(Locale.US, "%.1f", maxValue), dp(2f), top + dp(17f), textPaint)
        canvas.drawText(String.format(Locale.US, "%.1f", minValue), dp(2f), bottom, textPaint)
        drawTimeLabels(canvas, left, right, now)
        if (visible.size == 1) {
            val point = visible.single()
            val x = left + ((point.timestamp - (now - rangeMs)).toFloat() / rangeMs).coerceIn(0f, 1f) * (right - left)
            val y = bottom - ((point.value - low) / span).toFloat() * (bottom - top)
            canvas.drawCircle(x, y, dp(2.5f), pointPaint)
            return
        }
        val plotted = visible.map { point ->
            val x = left + ((point.timestamp - (now - rangeMs)).toFloat() / rangeMs).coerceIn(0f, 1f) * (right - left)
            val y = bottom - ((point.value - low) / span).toFloat() * (bottom - top)
            x to y
        }
        buildSmoothPath(plotted)
        fillPath.set(path)
        fillPath.lineTo(plotted.last().first, bottom)
        fillPath.lineTo(plotted.first().first, bottom)
        fillPath.close()
        fillPaint.shader = LinearGradient(
            0f,
            top,
            0f,
            bottom,
            linePaint.color and 0x00FFFFFF or (0x48 shl 24),
            linePaint.color and 0x00FFFFFF,
            Shader.TileMode.CLAMP
        )
        canvas.drawPath(fillPath, fillPaint)
        fillPaint.shader = null
        canvas.drawPath(path, linePaint)
        val lastPoint = visible.last()
        val lastX = plotted.last().first
        val lastY = plotted.last().second
        canvas.drawCircle(lastX, lastY, dp(2.5f), pointPaint)
    }

    private fun buildSmoothPath(points: List<Pair<Float, Float>>) {
        path.rewind()
        val first = points.first()
        path.moveTo(first.first, first.second)
        if (points.size == 1) return
        for (index in 0 until points.lastIndex) {
            val start = points[index]
            val end = points[index + 1]
            val previous = points.getOrElse(index - 1) { start }
            val next = points.getOrElse(index + 2) { end }
            val control1X = start.first + (end.first - previous.first) / 6f
            val control1Y = start.second + (end.second - previous.second) / 6f
            val control2X = end.first - (next.first - start.first) / 6f
            val control2Y = end.second - (next.second - start.second) / 6f
            path.cubicTo(control1X, control1Y, control2X, control2Y, end.first, end.second)
        }
    }

    private fun drawTimeLabels(canvas: Canvas, left: Float, right: Float, now: Long) {
        val pattern = if (rangeMs >= 86_400_000L) "MMM d" else "HH:mm"
        val format = SimpleDateFormat(pattern, Locale.getDefault())
        val baseline = height - dp(5f)
        canvas.drawText(format.format(Date(now - rangeMs)), left, baseline, textPaint)
        val middleLabel = format.format(Date(now - rangeMs / 2))
        val middleWidth = textPaint.measureText(middleLabel)
        canvas.drawText(middleLabel, (left + right - middleWidth) / 2f, baseline, textPaint)
        val nowWidth = textPaint.measureText("now")
        canvas.drawText("now", right - nowWidth, baseline, textPaint)
    }

    private fun dp(value: Float): Float = value * resources.displayMetrics.density
}
